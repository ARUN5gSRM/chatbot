# ss_app/sub_models/activity_log_models.py
from django.db import models
from django.contrib.auth.models import User


class UserActivityLog(models.Model):
    ACTION_CHOICES = [
        # Chat
        ("CHAT_QUERY", "Chat Query"),
        ("CHAT_RETRIEVAL", "Chat Retrieval"),
        ("CHAT_DECISION", "Chat Decision"),
        ("CHAT_RESPONSE", "Chat Response"),
        ("CHAT_CONFIRMATION", "Chat Confirmation"),

        # Ticket
        ("TICKET_PROMPTED", "Ticket Prompted"),
        ("TICKET_REQUESTED", "Ticket Requested"),
        ("TICKET_CREATED", "Ticket Created"),
        ("TICKET_FAILED", "Ticket Failed"),

        # Uploads
        ("UPLOAD_EXCEL_STARTED", "Upload Excel Started"),
        ("UPLOAD_EXCEL_COMPLETED", "Upload Excel Completed"),
        ("UPLOAD_PDF_STARTED", "Upload PDF Started"),
        ("UPLOAD_PDF_COMPLETED", "Upload PDF Completed"),
        ("CRAWL_STARTED", "Crawl Started"),
        ("CRAWL_COMPLETED", "Crawl Completed"),

        # Auth / Session
        ("USER_LOGIN", "User Login"),
        ("USER_LOGOUT", "User Logout"),
        ("SESSION_CLEARED", "Session Cleared"),
    ]

    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    session_key = models.CharField(max_length=64, blank=True)

    action = models.CharField(max_length=50, choices=ACTION_CHOICES)
    message = models.TextField(blank=True)
    metadata = models.JSONField(default=dict, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "user_activity_logs"
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.action} | {self.user or 'anonymous'}"
