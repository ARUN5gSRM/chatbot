# ss_app/sub_views/auth_view.py
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from ..forms import CustomUserCreationForm
from ..logic.index_manager import faiss_manager
from ..logic.activity_logger import log_activity

def signup_view(request):
    if request.method == "POST":
        form = CustomUserCreationForm(request.POST)
        role = request.POST.get("role")

        if form.is_valid():
            user = form.save(commit=False)

            # ROLE HANDLING
            user.is_staff = (role == "admin")

            user.save()

            messages.success(
                request,
                "Account created successfully. Please log in."
            )
            return redirect("ss_app:login")

        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = CustomUserCreationForm()

    return render(request, "ss_app/signup.html", {"form": form})


def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)

            log_activity(
                request=request,
                action="USER_LOGIN",
                message=user.username,
            )

            messages.success(request, f"Welcome {user.username}!")
            return redirect("ss_app:index")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()

    return render(request, "ss_app/login.html", {"form": form})


@login_required
def logout_view(request):
    session_key = request.session.session_key

    log_activity(
        request=request,
        action="USER_LOGOUT",
    )

    if session_key:
        tickets_ns = f"tickets_session_{session_key}"
        pdf_ns = f"pdf_session_{session_key}"

        if tickets_ns in faiss_manager.indices:
            faiss_manager.indices.pop(tickets_ns, None)
        if pdf_ns in faiss_manager.indices:
            faiss_manager.indices.pop(pdf_ns, None)

    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect("ss_app:login")
