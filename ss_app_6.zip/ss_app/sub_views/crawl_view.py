# ss_app/sub_views/crawl_view.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods

from ..logic.crawler_logic import crawl_site
from ..logic.activity_logger import log_activity  # ✅ ADDED


@login_required
@require_http_methods(["GET", "POST"])
def crawl_site_view(request):
    result = None

    if request.method == "POST":
        url = request.POST.get("url", "").strip()
        max_pages = int(request.POST.get("max_pages", 5))
        delay = float(request.POST.get("delay", 0.5))

        if url:
            # ✅ LOG: crawl started
            log_activity(
                request=request,
                action="CRAWL_STARTED",
                message=url,
                metadata={
                    "max_pages": max_pages,
                    "delay": delay,
                },
            )

            try:
                result = crawl_site(url, max_pages=max_pages, delay=delay)

                # ✅ LOG: crawl completed
                log_activity(
                    request=request,
                    action="CRAWL_COMPLETED",
                    metadata={
                        "pages_crawled": result.get("pages_crawled"),
                        "paragraphs_created": result.get("paragraphs_created"),
                    },
                )

            except Exception as e:
                # ✅ LOG: crawl failed
                log_activity(
                    request=request,
                    action="CRAWL_FAILED",
                    metadata={
                        "error": str(e),
                        "url": url,
                    },
                )
                raise

    return render(request, "ss_app/crawl_site.html", {
        "result": result,
    })
