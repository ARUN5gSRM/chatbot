import logging
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.shortcuts import render, redirect, get_object_or_404
from ..models import AutoTicket
from ..integrations.servicenow_client import (
    create_incident_from_chatbot,
    resolve_incident,
)
from ..logic.email_utils import (
    send_ticket_created_email,
    send_ticket_resolved_email,
)
from ..logic.activity_logger import log_activity

logger = logging.getLogger(__name__)


def generate_ticket_from_chat(request):
    user = request.user

    confirmation = request.session.get("confirmation")
    last_query = request.session.get("last_query", "")
    last_results = request.session.get("last_results", [])
    last_bot_response = request.session.get("last_bot_response", "")
    chat_history = request.session.get("chat_history", [])

    priority = "HIGH" if any(
        k in last_query.lower() for k in ["urgent", "critical", "fail", "error"]
    ) else "MEDIUM"

    # -------------------------------------------------
    # ALWAYS CREATE INCIDENT (YES or NO)
    # -------------------------------------------------
    log_activity(
        request=request,
        action="TICKET_REQUESTED",
        message=last_query,
    )

    sys_id, incident_number = create_incident_from_chatbot(
        short_desc=last_query,
        description=last_bot_response,
    )

    auto_ticket = AutoTicket.objects.create(
        ticket_id=incident_number,
        user=user,
        user_name=user.username,
        timestamp=timezone.now(),
        query_text=last_query,
        last_bot_responses={"responses": [last_bot_response]},
        retrieved_results={"results": last_results},
        similarity_threshold_used=0.0,
        chat_history={"conversation": chat_history[-10:]},
        assigned_to="ServiceNow",
        priority=priority,
    )

    # -------------------------------------------------
    # USER SAID YES → CLOSE THE SAME INCIDENT
    # -------------------------------------------------
    if confirmation in {"yes", "y", "resolved", "works"}:
        resolution_notes = (
            last_bot_response or
            "Issue resolved automatically after user confirmation."
        )

        resolve_incident(sys_id, resolution_notes)

        send_ticket_resolved_email(
            user=user,
            incident_number=incident_number,
            resolution_notes=resolution_notes,
        )

        log_activity(
            request=request,
            action="TICKET_CREATED",
            metadata={
                "incident": incident_number,
                "status": "RESOLVED",
            },
        )

        messages.success(
            request,
            f"Incident {incident_number} was created and resolved successfully."
        )

    # -------------------------------------------------
    # USER SAID NO → LEAVE INCIDENT OPEN
    # -------------------------------------------------
    else:
        send_ticket_created_email(
            user=user,
            incident_number=incident_number,
            priority=priority,
            summary=last_query,
        )

        log_activity(
            request=request,
            action="TICKET_CREATED",
            metadata={
                "incident": incident_number,
                "status": "OPEN",
            },
        )

        messages.success(
            request,
            f"ServiceNow Incident {incident_number} created successfully."
        )

    request.session.pop("awaiting_confirmation", None)
    request.session.pop("confirmation", None)

    return redirect(
        "ss_app:auto_ticket_summary",
        ticket_id=incident_number
    )
@login_required
def auto_ticket_summary_view(request, ticket_id):
    ticket = get_object_or_404(AutoTicket, ticket_id=ticket_id)
    return render(request, "ss_app/auto_ticket_summary.html", {"ticket": ticket})
