# ss_app/sub_views/chatbot_view.py
import json
from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponseBadRequest
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods

from ..logic.index_manager import faiss_manager
from ..logic.unified_chatbot import unified_chatbot_search
from ..logic.session_helpers import get_recent_conversation, clear_conversation
from ..models import Ticket
from ..logic.activity_logger import log_activity  # ✅ logging import

NAMESPACE_TICKETS_BASE = "tickets_session_"

CONFIRM_YES = {"yes", "y", "ok", "resolved", "works"}
CONFIRM_NO = {"no", "n", "not working", "fail"}


def _ensure_session_namespace(request) -> str:
    if not request.session.session_key:
        request.session.save()

    session_key = request.session.session_key
    ns = f"{NAMESPACE_TICKETS_BASE}{session_key}"

    faiss_manager.safe_get_or_create(ns)
    faiss_manager.safe_build_from_db_if_empty(
        ns,
        lambda: list(
            Ticket.objects.filter(embedding__isnull=False).values_list("id", "embedding")
        )
    )
    return ns


@login_required
@require_http_methods(["GET", "POST"])
def chatbot_view(request):
    query = ""
    results = {}

    if request.method == "POST":
        try:
            if request.content_type == "application/json":
                payload = json.loads(request.body.decode("utf-8") or "{}")
                query = (payload.get("query") or "").strip()
            else:
                query = (request.POST.get("query") or "").strip()
        except Exception:
            return HttpResponseBadRequest("Invalid request payload")

        if query:
            # ✅ LOG: user asked a question
            log_activity(
                request=request,
                action="CHAT_QUERY",
                message=query,
            )

            # ---------- CONFIRMATION HANDLING ----------
            if request.session.get("awaiting_confirmation"):
                q = query.lower()

                if q in CONFIRM_YES or q in CONFIRM_NO:
                    # ✅ LOG: user confirmation response
                    log_activity(
                        request=request,
                        action="CHAT_CONFIRMATION",
                        message=q,
                    )
                    request.session["confirmation"] = q
                    return redirect("ss_app:auto_ticket")

            _ensure_session_namespace(request)
            results = unified_chatbot_search(request, query)

            if request.headers.get("x-requested-with") == "XMLHttpRequest":
                return JsonResponse(results)

    else:
        results = {"chat_history": get_recent_conversation(request)}

    return render(request, "ss_app/chatbot.html", {
        "results": results,
        "query": query
    })


@login_required
@require_http_methods(["POST", "GET"])
def clear_chat_view(request):
    clear_conversation(request)

    # ✅ LOG: session/chat cleared
    log_activity(
        request=request,
        action="SESSION_CLEARED",
    )

    if not request.session.session_key:
        request.session.save()

    session_key = request.session.session_key
    if session_key:
        ns = f"{NAMESPACE_TICKETS_BASE}{session_key}"
        faiss_manager.safe_pop(ns)

    return redirect("ss_app:chatbot")
