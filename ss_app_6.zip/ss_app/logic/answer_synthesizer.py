from typing import List, Dict, Optional
from .llm_client import llm_client

MIN_EVIDENCE_CHARS = 50


def _build_prompt(query: str, evidence: List[Dict]) -> str:
    snippets = []

    for i, r in enumerate(evidence, start=1):
        src = r["source"]
        p = r["payload"]

        if src == "TICKET":
            text = f"""
Short Description: {p.get("short_description", "")}
RCA: {p.get("rca", "")}
Solution: {p.get("solution", "")}
"""
        elif src == "PDF":
            text = p.get("text", "")
        elif src == "WEB":
            text = p.get("best_sentence", "")
        else:
            continue

        if text.strip():
            snippets.append(f"[{i}] {text.strip()}")

    joined = "\n\n".join(snippets)

    if len(joined) < MIN_EVIDENCE_CHARS:
        return ""

    return f"""
You are a support assistant.

You MUST follow the rules below exactly.

RULES:
- Answer ONLY using the verified information.
- Do NOT use external knowledge.
- Do NOT infer user-specific states.
- Use cautious, conditional language.
- If the information is insufficient, you MUST say so.

OUTPUT FORMAT (MANDATORY):
You must respond in EXACTLY this JSON format and nothing else:

{{
  "verdict": "SUPPORTED" | "INSUFFICIENT",
  "answer": "<answer text or empty string>"
}}

VERDICT RULES:
- Use "SUPPORTED" ONLY if the answer is fully supported by the verified information.
- Use "INSUFFICIENT" if the information does not reliably answer the question.

User question:
{query}

Verified information:
{joined}
"""


def _parse_llm_response(raw: str) -> Optional[str]:
    """
    Strict parser for LLM response.
    Returns answer text only if verdict == SUPPORTED.
    """
    if not raw:
        return None

    raw = raw.strip()

    try:
        import json
        data = json.loads(raw)
    except Exception:
        # Invalid / non-JSON output → reject
        return None

    verdict = data.get("verdict")
    answer = data.get("answer", "").strip()

    if verdict != "SUPPORTED":
        return None

    if not answer:
        return None

    return answer


def synthesize_answer(
        query: str,
        ranked_results: List[Dict]
) -> Optional[str]:
    prompt = _build_prompt(query, ranked_results)
    if not prompt:
        return None

    response = llm_client.generate(prompt)
    if not response:
        return None

    # ✅ HARD, STRUCTURED HALLUCINATION GUARD
    return _parse_llm_response(response)
