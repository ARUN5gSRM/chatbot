# ss_app/logic/unified_chatbot.py
from typing import List, Dict, Any
from ..logic.chatbot_core import semantic_search as ticket_search
from ..logic.pdf_core import pdf_search
from ..logic.retriever_logic import semantic_search as web_search
from ..logic.orchestration_agent import decide_action
from ..logic.answer_synthesizer import synthesize_answer

from ..logic.session_helpers import (
    init_session_history_if_needed,
    append_user_message,
    append_assistant_message,
    get_recent_conversation,
)

from ..logic.activity_logger import log_activity

GLOBAL_TOP_K = 3


def _normalize_score(score: float) -> float:
    try:
        return round(float(score), 4)
    except Exception:
        return 0.0


def unified_chatbot_search(request, query: str) -> Dict[str, Any]:

    # Session + user message
    init_session_history_if_needed(request)
    append_user_message(request, query)

    aggregated: List[Dict[str, Any]] = []

    # ---------------- TICKETS ----------------
    try:
        ticket_hits = ticket_search(query)
    except Exception:
        ticket_hits = []

    for h in ticket_hits:
        aggregated.append({
            "source": "TICKET",
            "score": _normalize_score(h.get("score")),
            "payload": h,
        })

    # ---------------- PDF ----------------
    try:
        pdf_hits = pdf_search(query, top_k=GLOBAL_TOP_K)
    except Exception:
        pdf_hits = []

    for h in pdf_hits:
        aggregated.append({
            "source": "PDF",
            "score": _normalize_score(h.get("score")),
            "payload": h,
        })

    # ---------------- WEB ----------------
    try:
        web_hits = web_search(query, top_k=GLOBAL_TOP_K)
    except Exception:
        web_hits = []

    for h in web_hits:
        aggregated.append({
            "source": "WEB",
            "score": _normalize_score(h.get("semantic_score", 0.0)),
            "payload": h,
        })

    # ✅ LOG: retrieval summary
    log_activity(
        request=request,
        action="CHAT_RETRIEVAL",
        metadata={
            "ticket_hits": len(ticket_hits),
            "pdf_hits": len(pdf_hits),
            "web_hits": len(web_hits),
        },
    )

    # -------- NO RESULTS → ESCALATE --------
    if not aggregated:
        msg = (
            "No reliable solution was found.\n\n"
            "Would you like me to raise a support ticket?"
        )

        append_assistant_message(request, msg)

        request.session["awaiting_confirmation"] = True
        request.session["last_query"] = query
        request.session["last_results"] = []
        request.session.modified = True

        return {
            "message": msg,
            "results": [],
            "chat_history": get_recent_conversation(request),
        }

    # -------- GLOBAL RANKING --------
    ranked = sorted(
        aggregated,
        key=lambda x: x["score"],
        reverse=True
    )[:GLOBAL_TOP_K]

    # -------- ORCHESTRATION --------
    action = decide_action(ranked)

    # ✅ LOG: orchestration decision
    log_activity(
        request=request,
        action="CHAT_DECISION",
        message=action,
        metadata={
            "sources": [r["source"] for r in ranked],
            "scores": [r["score"] for r in ranked],
        },
    )

    # -------- LLM SYNTHESIS (NEW) --------
    if action == "PRESENT_SOLUTION":
        synthesized = synthesize_answer(query, ranked)

        if synthesized:
            final_message = (
                synthesized
                + "\n\n---\n\n"
                + "✅ Does this solution resolve your issue? (Yes / No)"
            )
        else:
            final_message = (
                "I could not generate a reliable answer from the available data.\n\n"
                "Would you like me to raise a support ticket?"
            )
    else:
        final_message = (
            "I could not find a reliable solution.\n\n"
            "Would you like me to raise a support ticket?"
        )

    append_assistant_message(request, final_message)

    # ✅ LOG: final response sent to user
    log_activity(
        request=request,
        action="CHAT_RESPONSE",
        message=final_message,
        metadata={
            "result_count": len(ranked),
        },
    )

    request.session["awaiting_confirmation"] = True
    request.session["last_query"] = query
    request.session["last_results"] = ranked
    request.session.modified = True

    return {
        "message": final_message,
        "results": ranked,
        "chat_history": get_recent_conversation(request),
    }
