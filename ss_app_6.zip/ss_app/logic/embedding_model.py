# ss_app/logic/embedding_model.py
from typing import List, Optional
import numpy as np
import os
import requests
from dotenv import load_dotenv
EMBED_DIM = 768
MAX_EMBED_CHARS = 4000
load_dotenv()
# Azure Ollama embedding endpoint
AZURE_EMBED_URL = os.getenv(
    "AZURE_EMBED_URL",
    "http://azdtapimanager.azure-api.net/ollama/api/embed"
)
AZURE_EMBED_API_KEY = os.getenv("AZURE_EMBED_API_KEY")


class EmbeddingModel:


    def __init__(self):
        self.dim = EMBED_DIM

    def _normalize(self, vec: List[float]) -> List[float]:
        arr = np.asarray(vec, dtype="float32")
        norm = np.linalg.norm(arr)
        if norm == 0 or np.isnan(norm):
            return [0.0] * self.dim
        return (arr / norm).tolist()

    def _embed_single(self, text: str) -> List[float]:
        if not AZURE_EMBED_API_KEY:
            raise RuntimeError("AZURE_EMBED_API_KEY is not set")

        safe_text = text[:MAX_EMBED_CHARS]
        print(f"[EMBED] sending text of length{len(safe_text)}")
        response = requests.post(
            AZURE_EMBED_URL,
            headers={
                "api-key": AZURE_EMBED_API_KEY,
                "Content-Type": "application/json",
            },
            json={
                "model": "nomic-embed-text",
                "input": safe_text,
            },
            timeout=(5, 60),
        )
        print("[EMBED]RESPONSE received")
        if response.status_code != 200:
            raise RuntimeError(
                f"Embedding API failed: {response.status_code} {response.text}"
            )

        data = response.json()

        embeddings = data.get("embeddings")
        if not isinstance(embeddings, list) or not embeddings:
            raise RuntimeError("Invalid embedding response format")

        embedding = embeddings[0]

        if len(embedding) != EMBED_DIM:
            raise RuntimeError(
                f"Embedding dim mismatch: expected {EMBED_DIM}, got {len(embedding)}"
            )

        return self._normalize(embedding)

    def _embed_batch(self, texts: List[str]) -> List[List[float]]:
        results: List[List[float]] = []
        for text in texts:
            results.append(self._embed_single(text))
        return results

    def generate_embedding(self, text: str) -> Optional[List[float]]:
        if not text or not isinstance(text, str):
            return None
        return self._embed_batch([text])[0]

    def generate_batch(self, texts: List[str]) -> List[List[float]]:
        if not texts:
            return []
        return self._embed_batch(texts)


# Public singleton preserved
default_embedder = EmbeddingModel()
