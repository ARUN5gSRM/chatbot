from django.core.mail import send_mail
from django.conf import settings
import logging

logger = logging.getLogger(__name__)


def _get_recipient_email(user):

    if user and user.email:
        return user.email.strip()
    return None


def send_ticket_created_email(user, incident_number, priority, summary):
    recipient = _get_recipient_email(user)

    if not recipient:
        logger.warning(
            f"Email not sent for ticket {incident_number}: user email is empty"
        )
        return

    subject = f"[ServiceNow] Ticket Created: {incident_number}"

    message = f"""
Hello {user.username},

Your support request has been created.

Ticket ID: {incident_number}
Status: New
Priority: {priority}

Summary:
{summary}

Regards,
GenAI Support System
"""

    send_mail(
        subject,
        message.strip(),
        settings.EMAIL_HOST_USER,
        [recipient],
        fail_silently=False,
    )


def send_ticket_resolved_email(user, incident_number, resolution_notes):
    recipient = _get_recipient_email(user)

    if not recipient:
        logger.warning(
            f"Email not sent for ticket {incident_number}: user email is empty"
        )
        return

    subject = f"[ServiceNow] Ticket Resolved: {incident_number}"

    message = f"""
Hello {user.username},

Your support request has been resolved and closed.

Ticket ID: {incident_number}
Status: Resolved

Resolution:
{resolution_notes}

Regards,
GenAI Support System
"""

    send_mail(
        subject,
        message.strip(),
        settings.EMAIL_HOST_USER,
        [recipient],
        fail_silently=False,
    )
