# ss_app/logic/llm_client.py
import requests
import os
from typing import Optional

AZURE_LLM_URL = os.getenv(
    "AZURE_LLM_URL",
    "http://azdtapimanager.azure-api.net/ollama/api/generate"
)
AZURE_LLM_API_KEY = os.getenv("AZURE_LLM_API_KEY")
DEFAULT_MODEL = "llama3"


class LLMClient:
    def generate(self, prompt: str, model: str = DEFAULT_MODEL) -> Optional[str]:
        if not prompt.strip():
            return None

        resp = requests.post(
            AZURE_LLM_URL,
            headers={
                "api-key": AZURE_LLM_API_KEY,
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "prompt": prompt,
                "stream": False,
            },
            timeout=(5, 90),
        )

        if resp.status_code != 200:
            raise RuntimeError(f"LLM failed: {resp.status_code} {resp.text}")

        data = resp.json()
        return data.get("response", "").strip()


llm_client = LLMClient()
