# ss_app/logic/activity_logger.py
from typing import Optional, Dict, Any
from django.http import HttpRequest
from django.contrib.auth.models import AnonymousUser

from ..sub_models.activity_log_models import UserActivityLog


def log_activity(
    *,
    request: HttpRequest,
    action: str,
    message: str = "",
    metadata: Optional[Dict[str, Any]] = None,
):

    try:
        user = None
        if hasattr(request, "user") and not isinstance(request.user, AnonymousUser):
            user = request.user

        session_key = ""
        if hasattr(request, "session"):
            session_key = request.session.session_key or ""

        UserActivityLog.objects.create(
            user=user,
            session_key=session_key,
            action=action,
            message=message[:5000],
            metadata=metadata or {},
        )
    except Exception:
        pass
