# ss_app/logic/orchestration_agent.py
from typing import List, Dict, Any

CONFIDENCE_THRESHOLD = 0.50


def evaluate_confidence(results: List[Dict[str, Any]]) -> float:

    if not results:
        return 0.0
    return max(r.get("score", 0.0) for r in results)


def decide_action(results: List[Dict[str, Any]]) -> str:
    """
    Returns:
    - PRESENT_SOLUTION
    - ESCALATE
    """
    confidence = evaluate_confidence(results)

    if confidence >= CONFIDENCE_THRESHOLD:
        return "PRESENT_SOLUTION"

    return "ESCALATE"
