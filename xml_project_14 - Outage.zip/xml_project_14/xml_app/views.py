import json
import os, tempfile, logging, re
import subprocess
from datetime import timedelta, datetime
import io
import base64
from typing import Any
from django.core.paginator import Paginator
import matplotlib
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from fontTools.ttLib.tables.grUtils import entries

matplotlib.use('Agg')
import matplotlib.pyplot as plt
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, redirect
from django.contrib import messages
from django.utils import timezone
from django.utils.dateformat import format as df_format
from .models import CustomUser, PlannedOutage
from .forms import XMLUploadForm
from .utils import parse_xml_dynamic
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .forms import UserRegistrationForm, CustomLoginForm
from django.shortcuts import render, get_object_or_404
from .utils import parse_xml_dynamic  # if needed
from urllib.parse import unquote_plus, quote, unquote
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from .models import (
    ServerMetricsLive,
    ServerMetricsHistory,
    ServiceMetricsLive,
    ServiceMetricsHistory,
    ServiceComponentLive,
    ServiceComponentHistory,
    ApplicationDashboardLive,
    ApplicationDashboardHistory,
    ApplicationListLive,
    ApplicationListHistory,
    Application,
    ApplicationService,
    PlannedOutage,
    PlannedOutageHistory
)
from .utils import normalize_key
import datetime

from .sub_views import (
    outrage_list,
    outrage_create,
    outrage_update,
    outage_history,
    latest_events_details,
    application_map,
    application_service_map,
    application_detail_map,
    server_detail_map,
    latest_event_detail_map,
    service_map,
    service_component_map,
    application_server_map,
    application_server_more_details_map,

)
 # reuse your helper or copy it here


logger = logging.getLogger(__name__)

def get_app_cpu_color(value):
    try:
        if "%" in value:
            v = float(str(value).replace('%', '').strip())
            if v <= 65:
                return 'green'
            elif v <= 85:
                return 'orange'
            else:
                return 'red'
    except Exception:
        return 'green'

def get_color(value):
    if isinstance(value, list):
        disk_colors = []
        for d_value in value:
            if "Free" in d_value:
                d = re.search(r"(\d+\.\d+|\d+)GB", d_value)
                if float(d.group(1)) > 25:
                    disk_colors.append('green')
                elif float(d.group(1)) <= 25 and float(d.group(1)) > 10:
                    disk_colors.append('orange')
                else:
                    disk_colors.append('red')
        diskspace_data = [
            {"value": v, "colors": c}
            for v,c in zip(value, disk_colors)
        ]
        return diskspace_data


    # for string values
    if value.lower() == "up" or value.lower() == "running" or value == "True":
        return '#008000'
    elif value.lower() == "down" or value.lower() == "stopped" or value == "False":
        return 'red'
    elif not value:
        return 'green'

    try:
        if "%" in value:
            v = float(str(value).replace('%', '').strip())
            if v <= 65:
                return 'green'
            elif v <= 85:
                return 'yellow'
            else:
                return 'red'
        if "MB" in value:
            r = float(str(value).replace('MB', '').strip())
            if r > 10000:
                return 'green'
            elif r <= 10000 and r > 6000:
                return 'orange'
            else:
                return 'red'
        if "Free" in value:
            d = re.search(r"(\d+\.\d+|\d+)GB", value)
            print(d.group(1))
            if d.group(1) > 25:
                return 'green'
            elif d.group(1) <= 25 and d.group(1) > 10:
                return 'orange'
            else:
                return 'red'

    except Exception:
        return 'green'


def portal_home(request):
    return render(request, 'home.html')


def register_view(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            raw_password = form.cleaned_data['password']
            user.set_password(raw_password)
            user.save()
            messages.success(request, 'Registration successful. Please log in.')
            return redirect('login')
    else:
        form = UserRegistrationForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = CustomLoginForm(request, data=request.POST)
        if form.is_valid():
            email = form.cleaned_data['username']
            password = form.cleaned_data['password']
            # business_unit = form.cleaned_data['business_unit']
            user = authenticate(request, username=email, password=password)

            if user is not None:
                    # and user.business_unit == business_unit):
                login(request, user)
                messages.success(request, f"Welcome {user.email}! BU: {user.business_unit}")
                return redirect('dashboard_view')
            else:
                messages.error(request, 'Invalid business unit or credentials.')
    else:
        form = CustomLoginForm()
    return render(request, 'login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')


def upload_view(request):
    form = XMLUploadForm(request.POST or None, request.FILES or None)
    user_unit = request.user.business_unit
    if request.method == 'POST' and form.is_valid():
        xml_file = form.cleaned_data['xml_file']
        filename = os.path.basename(xml_file.name)
        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix='.xml') as tmp:
                for chunk in xml_file.chunks():
                    tmp.write(chunk)
                tmp_path = tmp.name
            data = parse_xml_dynamic(tmp_path)

            ServerMetricsHistory.objects.create(
                file_name=filename,
                data=data,
                user=request.user,  # who uploaded it
                business_unit=request.user.business_unit,  # their unit
            )

            messages.success(request, f"{filename} uploaded successfully.")
            return redirect('dashboard_view')
        except Exception as e:
            logger.exception("Upload error")
            messages.error(request, f"Error parsing XML: {e}")
        finally:
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass

    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    return render(request, 'portal_upload.html', {'form': form, 'name': name.upper(), 'business_unit': user_unit,})


KILL_CPU_THRESHOLD = 85
KILL_RAM_THRESHOLD = 85
KILL_DISK_THRESHOLD = 85


def dashboard_view(request):
    user_unit = request.user.business_unit
    selected_unit = request.GET.get('unit')  # from dropdown filter

    # Admin can filter by any unit or see all
    if user_unit == 'Admin':
        if selected_unit and selected_unit != 'All':
            xml_entries = ServerMetricsLive.objects.filter(business_unit=selected_unit).order_by('-updated_at')
        else:
            xml_entries = ServerMetricsLive.objects.all().order_by('-updated_at')
    else:
        # Regular users can only see their own unit’s data
        xml_entries = ServerMetricsLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    # build servers data for template
    servers = []
    for entry in xml_entries:
        data = entry.data.get('ServerMetrics', {})
        servers_data = data.get('Server', [])
        if isinstance(servers_data, dict):
            servers_data = [servers_data]

        for server in servers_data:

            cpu_val = float(str(server.get('CPU')).replace('%','').strip() or 0)
            ram_val = float(str(server.get('RAM')).replace('%','').strip() or 0)
            threshold_breach_cpu = cpu_val > KILL_CPU_THRESHOLD
            threshold_breach_ram = ram_val > KILL_RAM_THRESHOLD

            disks = server.get('Disks', {}).get('Disk', [])
            if isinstance(disks, dict):
                disks = [disks]
            disk_list = []
            disk_value_check = []
            for d in disks:
                drive = d.get('@Drive', '')
                usage = d.get('#text', '')
                disk_value_check.append(usage)
                disk_list.append({
                    'drive': drive,
                    'usage': usage,
                    'color': get_color(usage)
                })

            #disk value threshold check condition
            disk_value_condition = False
            for value in disk_value_check:
                if float(str(value).replace('%','')) > KILL_DISK_THRESHOLD:
                    disk_value_condition = True
                    break

            threshold_breach_disk = disk_value_condition

            contributor_list = server.get('TopMemoryProcesses', {}).get('Process', [])
            if isinstance(contributor_list, dict):
                contributor_list = [contributor_list]
            top_3 = []
            for contributor in contributor_list:
                process_name = contributor.get('@Name', '')
                process_used = contributor.get('@MemoryGB', '')
                top_3.append({
                    'process_name': process_name,
                    'process_used': process_used,
                })
            servers.append({
                # 'source_file': entry.file_name,
                # 'uploaded_at': entry.created_at,
                'hostname': server.get('@Hostname'),
                'ip': server.get('@IP'),
                'status': server.get('@Status'),
                'status_color': get_color(server.get('@Status')),
                'cpu': server.get('CPU'),
                'ram': server.get('RAM'),
                'cpu_color': get_color(server.get('CPU')),
                'ram_color': get_color(server.get('RAM')),
                'network_latency': server.get('Network_Latency'),
                'last_boot': server.get('Last_Boot_Time'),
                'disks': disk_list,
                'top_memory_processes': top_3,
                'threshold_breach_cpu': threshold_breach_cpu,
                'threshold_breach_ram': threshold_breach_ram,
                'threshold_breach_disk': threshold_breach_disk,
                'cpu_threshold': CPU_THRESHOLD,
                'ram_threshold': RAM_THRESHOLD,
                'disk_threshold': DISK_THRESHOLD,
            })
    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ' ,email)

    return render(request, 'portal_dashboard.html', {
        'servers': servers,
        'business_unit': user_unit,
        'selected_unit': selected_unit or 'All',
        'name': name.upper()
    })

@login_required
def server_services_view(request, hostname):
    hostname = unquote_plus(hostname).strip()
    user_unit = request.user.business_unit

    # choose entries visible to user
    if user_unit == 'Admin':
        entries = ServiceMetricsLive.objects.all().order_by('-updated_at')
    else:
        entries = ServiceMetricsLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    # svc_map = {}  # normalized_service_name -> {service_name, status, source_file, uploaded_at}
    svc_map = []
    for entry in entries:
        # prefer files that are service metrics (top tag contains "ServiceMetrics" or filename hints)
        if not isinstance(entry.data, dict) or not entry.data:
            continue
        top = list(entry.data.keys())[0]
        is_metrics = 'servicemetrics' in top.lower() or 'ServiceMetrics' in top


        if not is_metrics:
            continue

        # locate Server nodes
        data_root = entry.data.get(top) if top and top in entry.data else entry.data
        servers = data_root.get('Server', []) if isinstance(data_root, dict) else []
        if isinstance(servers, dict):
            servers = [servers]

        for s in servers:
            host_val = (s.get('@Hostname') or s.get('Hostname') or '').strip()
            if normalize_key(host_val) != normalize_key(hostname):
                continue
            service_details = s.get('Service',[]) or s.get('service',[])

            for service in service_details:
                svc_map.append({
                    'hostname': host_val,
                    'svc_name': service.get('@name',''),
                    'svc_status': service.get('@status',''),
                    'status_color': get_color(service.get('@status','')),
                    'svc_lastchecked': service.get('@lastchecked',''),
                    'svc_responsetime': service.get('@responsetime',''),
                    'svc_availability': service.get('@availability',''),
                    'svc_errorrate': service.get('@errorrate',''),
                    'svc_restartcount': service.get('@restartcount',''),
                })
            # services may be 'service1','service2' ... or 'service' list/dict
            # for key, value in s.items():
            #     if not key.lower().startswith('service'):
            #         continue
            #     # value might be dict with '@name' and '#text' or plain text
            #     if isinstance(value, dict):
            #         svc_name = value.get('@name') or value.get('name') or key
            #         # if status appears as text (child text) or attribute
            #         svc_status = value.get('#text') or value.get('@status') or value.get('status') or ''
            #         svc_lastchecked = value.get('#text') or value.get('@lastchecked') or value.get('lastchecked') or ''
            #         svc_responsetime = value.get('#text') or value.get('@responsetime') or value.get('responsetime') or ''
            #         svc_availability = value.get('#text') or value.get('@availability') or value.get('availability') or ''
            #         svc_errorrate = value.get('#text') or value.get('@errorrate') or value.get('errorrate') or ''
            #         svc_restartcount = value.get('#text') or value.get('@restartcount') or value.get('restartcount') or ''
            #     else:
            #         # plain text or string
            #         svc_name = value if isinstance(value, str) else key
            #         svc_status = ''  # no explicit status inside this type
            #         svc_lastchecked = ''
            #         svc_responsetime = ''
            #         svc_availability = ''
            #         svc_errorrate = ''
            #         svc_restartcount = ''
            #
            #     if not svc_name:
            #         svc_name = key
            #
            #     n = normalize_key(svc_name)
            #     # store latest (entries ordered by -created_at)
            #     if n not in svc_map:
            #         svc_map[n] = {
            #             'service_name': svc_name,
            #             'status': svc_status,
            #             'status_color': get_color(svc_status),
            #             'lastchecked':svc_lastchecked,
            #             'responsetime':svc_responsetime,
            #             'availability':svc_availability,
            #             'errorrate':svc_errorrate,
            #             'restartcount':svc_restartcount,
            #             # 'source_file': entry.file_name,
            #             # 'uploaded_at': entry.created_at
            #         }
    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)
    # Also handle cases where ServiceMetrics used 'service' key with list/dict of @name and inner text as status:
    # (example earlier had <service1 name="...">Running</service1> which we covered above)
    # services = sorted(svc_map.values(), key=lambda x: (x['service_name'] or '').lower())
    print(svc_map)
    return render(request, 'server_services.html', {
        'hostname': hostname,
        # 'services': services,
        'services':svc_map,
        'name': name.upper(),
        'business_unit': user_unit,
    })



# @login_required
# def service_details_view(request, hostname, service_name):
#     hostname = unquote_plus(hostname).strip()
#     service_name = unquote_plus(service_name).strip()
#     user_unit = request.user.business_unit
#     # print("Debug >> hostname: ",hostname)
#     # print("Debug >> service name: ",service_name)
#     if user_unit == 'Admin':
#         entries = ServiceComponentData.objects.all().order_by('-created_at')
#     else:
#         entries = ServiceComponentData.objects.filter(business_unit=user_unit).order_by('-created_at')
#
#     components = []
#
#     for entry in entries:
#         data_root = entry.data.get('ServiceComponent') or entry.data.get('ServiceMetrics') or entry.data
#         servers = data_root.get('Server', []) if isinstance(data_root, dict) else []
#         if isinstance(servers, dict):
#             servers = [servers]
#
#         for s in servers:
#             host = (s.get('@Hostname') or s.get('Hostname') or '').strip()
#             if not host or host.lower() != hostname.lower():
#                 continue
#
#             svc_entries = s.get('service')
#             if not svc_entries:
#                 continue
#             if isinstance(svc_entries, dict):
#                 svc_entries = [svc_entries]
#
#             # find service by @name (case-insensitive)
#             matched = None
#             for sv in svc_entries:
#                 sv_name = (sv.get('@name') or sv.get('name') or '').strip()
#                 if sv_name and sv_name.lower() == service_name.lower():
#                     matched = sv
#                     break
#             if not matched:
#                 continue
#
#             assoc = matched.get('associated_component') or matched.get('associated') or matched.get('associated_component_list')
#             if not assoc:
#                 continue
#             assoc_list = assoc if isinstance(assoc, list) else [assoc]
#
#             for comp in assoc_list:
#                 comp_name = comp.get('@name') or comp.get('name') or ''
#                 comp_status = comp.get('@status') or comp.get('status') or ''
#                 comp_url = comp.get('@url') or comp.get('url') or ''
#                 comp_log = (comp.get('@logFile') or comp.get('logfile') or comp.get('logFile') or '')
#                 actual_service = comp.get('@actual_service_name') or comp.get('actual_service_name') or ''
#                 components.append({
#                     'component_name': comp_name,
#                     'status': comp_status,
#                     'url': comp_url,
#                     'logfile': comp_log,
#                     'actual_service': actual_service,
#                     # 'source_file': entry.file_name,
#                     # 'uploaded_at': entry.created_at
#                 })
#
#     return render(request, 'service_details.html', {
#         'hostname': hostname,
#         'service_name': service_name,
#         'components': components
#     })
#

@login_required
def service_details_view(request, hostname, service_name):
    hostname = unquote_plus(hostname).strip()
    service_name = unquote_plus(service_name).strip()
    user_unit = request.user.business_unit

    if user_unit == 'Admin':
        entries = ServiceComponentLive.objects.all().order_by('-updated_at')
    else:
        entries = ServiceComponentLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    components = []

    for entry in entries:
        # Only look at ServiceComponent files (top tag or filename)
        if not isinstance(entry.data, dict) or not entry.data:
            continue
        top = list(entry.data.keys())[0]
        is_component_data = 'servicecomponent' in top.lower() or 'ServiceComponent' in top

        if not is_component_data:
            continue

        # data root and Servers list
        data_root = entry.data.get(top) if (top and top in entry.data) else entry.data
        servers = data_root.get('Server', []) if isinstance(data_root, dict) else []
        if isinstance(servers, dict):
            servers = [servers]

        for s in servers:
            host_val = (s.get('@Hostname') or s.get('Hostname') or '').strip()
            if normalize_key(host_val) != normalize_key(hostname):
                continue

            # services may be under 'service' key as list/dict
            svc_entries = s.get('service') or s.get('Service') or {}
            if isinstance(svc_entries, dict):
                svc_entries = [svc_entries]
            if not svc_entries:
                # maybe services are directly children 'service1'...'serviceN' that contain associated_component
                # iterate through s's keys and find those starting with 'service' and containing associated_component
                for k, v in s.items():
                    if not k.lower().startswith('service'):
                        continue
                    sv = v
                    if isinstance(sv, dict):
                        sv_name = sv.get('@name') or sv.get('name') or ''
                        if normalize_key(sv_name) == normalize_key(service_name):
                            assoc = sv.get('associated_component') or sv.get('associated') or sv.get('associated_component_list')
                            if assoc:
                                assoc_list = assoc if isinstance(assoc, list) else [assoc]
                                for comp in assoc_list:
                                    comp_name = comp.get('@name') or comp.get('name') or ''
                                    comp_status = comp.get('@status') or comp.get('status') or ''
                                    comp_url = comp.get('@url') or comp.get('url') or ''
                                    comp_log = (comp.get('@logFile') or comp.get('logfile') or '')
                                    actual_service = comp.get('@actual_service_name') or comp.get('actual_service_name') or ''
                                    components.append({
                                        'component_name': comp_name,
                                        'status': comp_status,
                                        'url': comp_url,
                                        'logfile': comp_log,
                                        'actual_service': actual_service
                                    })
                continue

            # Now svc_entries is a list of service dicts — find the matching one by @name
            for sv in svc_entries:
                if not isinstance(sv, dict):
                    continue
                sv_name = (sv.get('@name') or sv.get('name') or '').strip()
                if normalize_key(sv_name) != normalize_key(service_name):
                    continue
                assoc = sv.get('associated_component') or sv.get('associated') or sv.get('associated_component_list')
                if not assoc:
                    continue
                assoc_list = assoc if isinstance(assoc, list) else [assoc]
                for comp in assoc_list:
                    comp_name = comp.get('@name') or comp.get('name') or ''
                    comp_status = comp.get('@status') or comp.get('status') or ''
                    comp_url = comp.get('@url') or comp.get('url') or ''
                    comp_log = comp.get('@logFile') or comp.get('@logfile') or comp.get('logFile') or comp.get('logfile') or ''
                    actual_service = comp.get('@actual_service_name') or comp.get('actual_service_name') or ''
                    components.append({
                        'component_name': comp_name,
                        'status': comp_status,
                        'url': comp_url,
                        'logfile': comp_log,
                        'actual_service': actual_service,
                    })
    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)
    # sort components by name
    # components = sorted(components, key=lambda x: (x.get('component_name') or '').lower())
    return render(request, 'service_details.html', {
        'hostname': hostname,
        'service_name': service_name,
        'components': components,
        'name': name.upper(),
        'business_unit': user_unit,
    })


@login_required
def application_dashboard_view(request):
    user_unit = request.user.business_unit
    selected_unit = request.GET.get('app_unit')

    if user_unit == 'Admin':
        if selected_unit and selected_unit != 'All':
            entries = ApplicationDashboardLive.objects.filter(business_unit=selected_unit).order_by('-updated_at')
        else:
            entries = ApplicationDashboardLive.objects.all().order_by('-updated_at')
    else:
        entries = ApplicationDashboardLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    print(entries)
    applications = []
    for entry in entries:
        data_root = entry.data.get('ApplicationDashboard') or entry.data.get('Application') or entry.data
        apps = data_root.get('Application', []) if isinstance(data_root, dict) else []
        if isinstance(apps, dict):
            apps = [apps]

        for app in apps:
            name = app.get('Name') or app.get('@name') or ''
            status = app.get('Status') or app.get('@status') or ''
            availability_uptime_percent = app.get('AvailabilityUptimePercent') or ''
            response_time_ms = app.get('ResponseTimeMs') or ''
            latency_ms = app.get('LatencyMs') or ''
            throughput_rps = app.get('ThroughputRPS') or ''
            database_query_latency_ms = app.get('DatabaseQueryLatencyMs') or ''
            error_rate_percent = app.get('ErrorRatePercent') or ''
            load_balancer_request_count = app.get('LoadBalancerRequestCount') or ''
            if name:
                applications.append({
                    'name': name.strip(),
                    'status_color': get_color(status),
                    'status': status,
                    'availability_uptime_percent': availability_uptime_percent,
                    'response_time_ms': response_time_ms,
                    'latency_ms': latency_ms,
                    'throughput_rps': throughput_rps,
                    'database_query_latency_ms': database_query_latency_ms,
                    'error_rate_percent': error_rate_percent,
                    'load_balancer_request_count': load_balancer_request_count,
                    'file': entry.app_name,
                })
    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    return render(request, 'application_list.html', {
        'applications': applications,
        'name': name.upper(),
        'selected_unit': selected_unit or 'All',
        'business_unit': user_unit,})


def normalize_pool_group(app_name):
    """
    Detect GS/BGS pools and map to their base module (T4X) dynamically.
    """
    if "POOL_GS" in app_name or "POOL_BGS" in app_name:
        # base_module = everything before GS/BGS + "_T4X"
        # detect prefix (e.g., ABC_, XYZ_)
        match = re.match(r"([A-Z0-9_]+)_POOL_", app_name)
        if match:
            prefix = match.group(1)
            return f"{prefix}_POOL_T4X"
    return app_name


@login_required
def application_detail_view(request, app_name):
    app_name = unquote_plus(app_name).strip()
    user_unit = request.user.business_unit

    resolved_name = normalize_pool_group(app_name)

    if user_unit == 'Admin':
        entries = ApplicationListLive.objects.all().order_by('-updated_at')
    else:
        entries = ApplicationListLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    servers = []
    for entry in entries:
        data_root = entry.data.get('ApplicationList') or entry.data.get('Application') or entry.data
        apps = data_root.get('Application', []) if isinstance(data_root, dict) else []
        if isinstance(apps, dict):
            apps = [apps]

        for app in apps:
            name = app.get('@name') or app.get('Name')
            if not name or name.strip().lower() != resolved_name.lower():
                continue

            srv_list = app.get('Server', [])
            if isinstance(srv_list, dict):
                srv_list = [srv_list]

            for s in srv_list:
                servers.append({
                    'name': s.get('@name') or '',
                    # 'env': s.get('@env') or '',
                    'hostname': s.get('@hostname') or '',
                    'cpu_color': get_app_cpu_color(s.get('@cpu') or ''),
                    'cpu': s.get('@cpu') or '',
                    'ram_color': get_color(s.get('@ram') or ''),
                    'ram': s.get('@ram') or '',
                    'diskspace_data': get_color((s.get('@diskspace').split(',') or '')),
                    # 'diskspace': (s.get('@diskspace') or '').split(','),
                    'pingstatus': s.get('@pingstatus') or '',
                    'lastchecked': s.get('@lastchecked') or '',
                    'status': s.get('@status') or '',
                })

    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    return render(request, 'application_detail.html', {
        'app_name': app_name,
        'servers': servers,
        'name': name.upper(),
        'business_unit': user_unit,
    })



@login_required
def application_server_more_details(request, app_name, server_name):
    server_name = unquote(server_name).strip()
    app_name = unquote(app_name).strip()
    user_unit = request.user.business_unit

    if user_unit == 'Admin':
        entries = ApplicationListLive.objects.all().order_by('-updated_at')
    else:
        entries = ApplicationListLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    details = None

    for entry in entries:
        data_root = entry.data.get('ApplicationList') or entry.data.get('Application') or entry.data
        apps = data_root.get('Application', []) if isinstance(data_root, dict) else []
        if isinstance(apps, dict):
            apps = [apps]

        for app in apps:
            name = app.get('@name') or app.get('Name')
            if not name or name.strip().lower() != app_name.lower():
                continue

            srv_list = app.get('Server', [])
            if isinstance(srv_list, dict):
                srv_list = [srv_list]

            for s in srv_list:
                if (s.get('@name') or '').strip().lower() == server_name.lower():

                    details = {
                        'server_name': server_name,
                        'ip': s.get('@ip') or '',
                        'os': s.get('@os') or '',
                        'os_version_build': s.get('@os_version_build') or '',
                        'network': s.get('@network') or '',
                        'remoteenabled': s.get('@remoteenabled') or '',
                    }
                    break

    if not details:
        messages.error(request, "Server details not found.")
        return redirect('application_more_detail', app_name=app_name)

    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    return render(request, "application_more_detail.html", {
        "app_name": app_name,
        "details": details,
        'name': name.upper(),
        'business_unit': user_unit,
    })


def _to_float(s):
    """Safe convert: '15' or '15%' -> 15.0; returns None on failure."""
    if s is None:
        return None
    if isinstance(s, (int, float)):
        return float(s)
    s = str(s).strip()
    if not s:
        return None
    # remove percent sign and non-numeric trailing text
    s = re.sub(r'[^0-9.\-]', '', s)
    try:
        return float(s)
    except Exception:
        return None

def _normalize_hostname(s):
    return (s or '').strip()

@login_required
def metrics_page_view(request):
    # page with three charts: CPU line, RAM line, Disk donut
    return render(request, 'metrics_page.html', {})


@login_required
def metrics_data_api(request):
    """
    Returns JSON with time-series CPU and RAM for a host, plus latest disk usage.
    Query params:
      - hostname (optional) : if provided, return metrics for that host only
      - limit (optional) : number of historical points to return, default 20
    """
    user_unit = request.user.business_unit
    hostname = request.GET.get('hostname')  # may be None -> aggregate
    try:
        limit = int(request.GET.get('limit', 20))
    except ValueError:
        limit = 20

    # Filter by BU
    # choose the model where ServiceMetrics are stored; modify if you used ServiceComponentData
    qs = ServerMetricsLive.objects.filter(business_unit=user_unit).order_by('-updated_at') if user_unit != 'Admin' else ServerMetricsLive.objects.all().order_by('-updated_at')

    # We'll collect up to `limit` samples (most recent first)
    labels = []     # timestamps string
    cpu_points = [] # floats
    ram_points = [] # floats

    # latest disks dict: drive -> value
    latest_disk = {}

    seen = 0
    # iterate rows newest->oldest until we collect `limit` points for the hostname (or collect aggregated)
    for entry in qs:
        if seen >= limit:
            break
        parsed = entry.data or {}
        # pick top tag (ServiceMetrics or similar)
        top = None
        if isinstance(parsed, dict):
            top = list(parsed.keys())[0] if parsed else None
        data_root = parsed.get(top) if (top and top in parsed) else parsed

        # servers may be list or dict
        servers = data_root.get('Server', []) if isinstance(data_root, dict) else []
        if isinstance(servers, dict):
            servers = [servers]

        for s in servers:
            host = (s.get('@Hostname') or s.get('Hostname') or '').strip()
            if hostname:
                hostname = hostname.replace(' ','')
                if host.lower() != hostname.lower():
                    continue

            # extract cpu, ram
            cpu_raw = s.get('CPU') or s.get('cpu') or s.get('@CPU') or s.get('#CPU')
            ram_raw = s.get('RAM') or s.get('ram') or s.get('@RAM') or s.get('#RAM')
            cpu = _to_float(cpu_raw)
            ram = _to_float(ram_raw)
            # skip if both None
            if cpu is None and ram is None:
                continue



            # record timestamp
            ts = entry.updated_at + timedelta(hours=5, minutes=30)
            labels.append(ts.strftime("%Y-%m-%d %H:%M:%S"))
            cpu_points.append(cpu if cpu is not None else None)
            ram_points.append(ram if ram is not None else None)

            # disk usage: get disks if available (take latest non-empty)
            disks = s.get('Disks') or s.get('disks') or {}
            # Disks may have 'Disk' key
            disk_nodes = []
            if isinstance(disks, dict):
                # try various shapes
                if 'Disk' in disks:
                    disk_nodes = disks.get('Disk') or []
                else:
                    # maybe directly dict of drives
                    disk_nodes = []
            if isinstance(disk_nodes, dict):
                disk_nodes = [disk_nodes]
            for d in disk_nodes:
                drive = d.get('@Drive') or d.get('Drive') or d.get('name') or ''
                used = d.get('#text') or d.get('@used') or d.get('used') or d.get('value')
                val = _to_float(used)
                if drive and val is not None:
                    # keep most recent (first encountered is latest)
                    if drive not in latest_disk:
                        latest_disk[drive] = val

            seen += 1
            if seen >= limit:
                break

    # reverse arrays so oldest -> newest for chart
    labels = labels[::-1]
    cpu_points = cpu_points[::-1]
    ram_points = ram_points[::-1]


    return JsonResponse({
        'labels': labels,
        'cpu': cpu_points,
        'ram': ram_points,
        'disks': latest_disk,
    })


@login_required
def metrics_dashboard(request):
    user_unit = request.user.business_unit
    if user_unit == 'Admin':
        entries = ServerMetricsLive.objects.all().order_by('-updated_at')
    else:
        entries = ServerMetricsLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    # get unique hostnames for dropdown
    hostnames = []
    for entry in entries:
        data_root = entry.data.get('ServiceMetrics') or entry.data.get('ServerMetrics') or entry.data
        servers = data_root.get('Server', []) if isinstance(data_root, dict) else []
        if isinstance(servers, dict):
            servers = [servers]
        for s in servers:
            hn = s.get('@Hostname') or s.get('Hostname')
            if hn and hn not in hostnames:
                hostnames.append(hn)
    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)
    return render(request, 'metrics_dashboard.html', {
        'hostnames': hostnames,
        'name': name.upper(),
        'business_unit': user_unit,
    })

@login_required
def metrics_data(request):
    server = request.GET.get('server')
    if not server:
        return JsonResponse({'error': 'No server provided'}, status=400)

    user_unit = request.user.business_unit

    # Filter only relevant XMLData entries
    if user_unit == 'Admin':
        entries = ServerMetricsLive.objects.all().order_by('-updated_at')
    else:
        entries = ServerMetricsLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    labels, cpu, ram = [], [], []
    disk_labels, disk_values = [], []
    server_info = {'hostname': server, 'ip': None, 'business_unit':user_unit}

    for entry in entries:
        data_root = entry.data.get('ServiceMetrics') or entry.data.get('ServerMetrics') or entry.data
        servers = data_root.get('Server', []) if isinstance(data_root, dict) else []
        if isinstance(servers, dict):
            servers = [servers]

        for s in servers:
            hn = (s.get('@Hostname') or s.get('Hostname') or '').strip()
            if hn.lower() != server.lower():
                continue

            ip_val = s.get('@IP') or s.get('IP') or None
            if ip_val:
                server_info['ip'] = ip_val

            # Get CPU and RAM
            cpu_val = None
            ram_val = None
            for key, value in s.items():
                if 'cpu' in key.lower():
                    cpu_val = float(str(value).replace('%', '').strip() or 0)
                if 'ram' in key.lower():
                    ram_val = float(str(value).replace('%', '').strip() or 0)

            ts = entry.updated_at.astimezone(timezone.get_current_timezone()).strftime('%Y-%m-%d %H:%M:%S')
            labels.append(ts)
            cpu.append(cpu_val or 0)
            ram.append(ram_val or 0)

            # Disk values
            disks = s.get('Disk', []) if isinstance(s.get('Disk', []), list) else [s.get('Disk', [])]
            for d in disks:
                if not isinstance(d, dict):
                    continue
                d_name = d.get('@Drive') or d.get('Drive')
                d_val = d.get('#text') or d.get('value') or ''
                if d_name and d_val:
                    disk_labels.append(d_name)
                    # Extract numeric value if like '50GB' or '60%'
                    num = ''.join(ch for ch in d_val if (ch.isdigit() or ch == '.'))
                    disk_values.append(float(num or 0))


    return JsonResponse({
        'labels': labels[::-1],  # reverse chronological order
        'cpu': cpu[::-1],
        'ram': ram[::-1],
        'disk_labels': disk_labels,
        'disk_values': disk_values,
        'server_info': server_info,
    })


@login_required
def all_servers_plot(request):
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    selected_metric = request.GET.get('metric', 'ALL')
    user_unit = request.user.business_unit
    selected_bu = request.GET.get('bu')

    if start_date and end_date:
        date_obj1 = datetime.datetime.strptime(start_date, "%Y-%m-%d").date()
        date_obj2 = datetime.datetime.strptime(end_date, "%Y-%m-%d").date()
        start_datetime = timezone.make_aware(datetime.datetime.combine(date_obj1, datetime.datetime.min.time()))
        end_datetime = timezone.make_aware(datetime.datetime.combine(date_obj2, datetime.datetime.max.time()))
    else:
        start_datetime = end_datetime = None

    if user_unit == 'Admin' and selected_bu and selected_bu == 'ALL':
        entries = ServerMetricsLive.objects.all().order_by('-updated_at')
    elif user_unit == 'Admin' and selected_bu and selected_bu != 'ALL':
        entries = ServerMetricsLive.objects.filter(business_unit=selected_bu).order_by('-updated_at')
    else:
        entries = ServerMetricsLive.objects.filter(business_unit=user_unit).order_by('-updated_at')
    if start_datetime and end_datetime:
        entries = entries.filter(updated_at__range=[start_datetime, end_datetime])


    # Collect metrics
    server_names = []
    cpu_vals = []
    ram_vals = []
    disk_data = {}  # e.g. {'C': [50, 70, 60], 'D': [100, 80, 120]}

    for entry in entries:
        data_root = entry.data.get('ServiceMetrics') or entry.data.get('ServerMetrics') or entry.data
        servers = data_root.get('Server', [])
        if isinstance(servers, dict):
            servers = [servers]

        for s in servers:
            name = s.get('@Hostname') or s.get('Hostname')
            if not name:
                continue

            cpu = None
            ram = None

            for k, v in s.items():
                if 'cpu' in k.lower():
                    cpu = float(str(v).replace('%', '').strip() or 0)
                if 'ram' in k.lower():
                    ram = float(str(v).replace('%', '').strip() or 0)

            # Disk handling
            disks = s.get('Disks', {}).get('Disk', [])
            if isinstance(disks, dict):
                disks = [disks]

            for d in disks:
                if not isinstance(d, dict):
                    continue
                drive = d.get('@Drive') or d.get('Drive') or 'Unknown'
                val = d.get('#text') or d.get('value') or ''
                num = ''.join(ch for ch in str(val) if ch.isdigit() or ch == '.')
                num = float(num or 0)
                if drive not in disk_data:
                    disk_data[drive] = []
                disk_data[drive].append(num)

            if cpu is not None and ram is not None:
                server_names.append(name)
                cpu_vals.append(cpu)
                ram_vals.append(ram)

    # --- Plotting ---
    fig, ax = plt.subplots(figsize=(10, 6))
    width = 0.15
    x = range(len(server_names))

    def autolabel(rects):
        """Attach a text label above each bar in *rects*, displaying its height."""
        for rect in rects:
            height = rect.get_height()
            ax.annotate('{}'.format(height),
                        xy=(rect.get_x() + rect.get_width() / 2, height),
                        xytext=(0, -2),  # 3 points vertical offset
                        textcoords="offset points",
                        ha='center', va='bottom')

    if selected_metric == 'ALL' or selected_metric == '':
        rects1 = ax.bar([i - width for i in x], cpu_vals, width, label='CPU (%)', color='magenta')
        rects2 = ax.bar(x, ram_vals, width, label='RAM (%)', color='cyan')

        # plot each drive dynamically
        color_cycle = ['tan', 'orange', 'mediumpurple', 'gold', 'lightcoral']
        for idx, (drive, values) in enumerate(disk_data.items()):
            offset = width * (idx + 1)
            color = color_cycle[idx % len(color_cycle)]
            rects3 = ax.bar([i + offset for i in x], values, width, label=f'Disk {drive} (GB)', color=color)
            autolabel(rects3)

        autolabel(rects1)
        autolabel(rects2)

    elif selected_metric == 'CPU':
        cpu_rects = ax.bar(x, cpu_vals, width, label='CPU (%)', color='magenta')
        autolabel(cpu_rects)

    elif selected_metric == 'RAM':
        ram_rects = ax.bar(x, ram_vals, width, label='RAM (%)', color='cyan')
        autolabel(ram_rects)

    else:
        color_cycle = ['tan', 'orange', 'mediumpurple', 'gold', 'lightcoral']
        for idx, (drive, values) in enumerate(disk_data.items()):
            offset = width * (idx + 1)
            color = color_cycle[idx % len(color_cycle)]
            disk_rects = ax.bar([i + offset for i in x], values, width, label=f'Disk {drive} (GB)', color=color)
            autolabel(disk_rects)

    ax.set_xticks(list(x))
    ax.set_xticklabels(server_names, rotation=45, ha='center')
    ax.set_ylabel('Usage')

    bar_print_label = ''
    if selected_metric == 'ALL' or selected_metric == '':
        bar_print_label = 'CPU, RAM, and Disk Usage (C, D, etc.)'
    else:
        bar_print_label = selected_metric

    ax.set_title(f'{bar_print_label} Usage Across Servers ({start_date} to {end_date})')
    ax.legend(
        loc = 'upper center',
        bbox_to_anchor = (0.5,1.2),
        ncol = 4,
        fontsize = 10,
        frameon = False,
        handlelength = 2.5,
        handletextpad = 0.8
    )

    ax.set_ylim(0,100)
    ax.set_yticks([0,20,40,60,80,100])

    plt.tight_layout()

    # Convert to base64
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    img_b64 = base64.b64encode(buf.read()).decode('utf-8')
    plt.close(fig)

    last_updated = timezone.now().astimezone(timezone.get_current_timezone()) + timedelta(hours=5, minutes=30)

    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    selectionTab = ['ALL','CPU', 'RAM', 'Disks']
    # for disk in disk_data.keys():
    #     selectionTab.append(disk.replace(' ',''))
    if start_date and end_date and start_date > end_date:
        return render(request, 'all_servers_plot.html', {
            'message': 'End Date must be after Start Date !!',
            'start_date': start_date,
            'end_date': end_date,
            'name': name.upper(),
            'business_unit': user_unit,
            'selectionTab': selectionTab,
        })

    elif start_date == '':
        return render(request, 'all_servers_plot.html', {
            'message': 'Please Select a Start Date !!',
            'start_date': start_date,
            'end_date': end_date,
            'name': name.upper(),
            'business_unit': user_unit,
            'selectionTab': selectionTab,
        })
    elif len(entries)!=0:
        return render(request, 'all_servers_plot.html', {
            'plot_image': img_b64,
            'last_updated': last_updated,
            'start_date':start_date,
            'end_date':end_date,
            'name': name.upper(),
            'business_unit': user_unit,
            'selectionTab':selectionTab,
            'selectedBU': selected_bu,
        })
    else:
        return render(request, 'all_servers_plot.html', {
            'message': f'No data found between {start_date} and {end_date}',
            'start_date': start_date,
            'end_date': end_date,
            'name': name.upper(),
            'business_unit': user_unit,
            'selectionTab': selectionTab,
        })


CPU_THRESHOLD_WARNING = 65
RAM_THRESHOLD_WARNING = 65
DISK_THRESHOLD_WARNING = 65

CPU_THRESHOLD = 85
RAM_THRESHOLD = 85
DISK_THRESHOLD = 85

Ticket_ID = 1000

@login_required
def check_threshold_view(request, server_name):
    global Ticket_ID
    user_unit = request.user.business_unit
    threshold_exceeded = []
    ticket_needed = False

    # Get the latest entry for this BU
    entries = ServerMetricsLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    if not entries.exists():
        messages.error(request, "No data available for this Business Unit.")
        return redirect('dashboard_view')


    selected_server = None
    for entry in entries:
        data_root = entry.data.get('ServiceMetrics') or entry.data.get('ServerMetrics') or entry.data
        servers = data_root.get('Server', [])
        if isinstance(servers, dict):
            servers = [servers]

        for server in servers:
            name = server.get('@Hostname') or server.get('Hostname')
            if name and name.lower() == server_name.lower():
                selected_server = server
                break

    if not selected_server:
        messages.error(request, f"No data found for {server_name}")
        return redirect('dashboard_view')

    # Extract metrics
    cpu_val = None
    ram_val = None
    disk_vals = []

    for k, v in selected_server.items():
        if 'cpu' in k.lower():
            cpu_val = float(str(v).replace('%', '').strip() or 0)
        elif 'ram' in k.lower():
            ram_val = float(str(v).replace('%', '').strip() or 0)

    disks = selected_server.get('Disks', {}).get('Disk', [])
    if isinstance(disks, dict):
        disks = [disks]

    for d in disks:
        drive = d.get('@Drive') or d.get('Drive') or 'Unknown'
        val = d.get('#text') or d.get('value') or ''
        num = ''.join(ch for ch in str(val) if ch.isdigit() or ch == '.')
        num = float(num or 0)
        disk_vals.append((drive, num))

    # Compare with thresholds
    if cpu_val and cpu_val < CPU_THRESHOLD and cpu_val > CPU_THRESHOLD_WARNING:
        threshold_exceeded.append(f"Warning: CPU usage {cpu_val}% nearing threshold of {CPU_THRESHOLD}%")
    elif cpu_val and cpu_val > CPU_THRESHOLD:
        threshold_exceeded.append(f"CPU usage {cpu_val}% exceeded the threshold of {CPU_THRESHOLD}%")
        ticket_needed = True
    if ram_val and ram_val < RAM_THRESHOLD and ram_val > RAM_THRESHOLD_WARNING:
        threshold_exceeded.append(f"Warning: RAM usage {ram_val}% nearing threshold of {RAM_THRESHOLD}%")
    elif ram_val and ram_val > RAM_THRESHOLD:
        threshold_exceeded.append(f"RAM usage {ram_val}% exceeded the threshold of {RAM_THRESHOLD}%")
        ticket_needed = True

    for drive, val in disk_vals:
        if val > DISK_THRESHOLD_WARNING and val < DISK_THRESHOLD:
            threshold_exceeded.append(f"Warning: Disk {drive} usage {val}% nearing the threshold of {DISK_THRESHOLD}%")
        elif val > DISK_THRESHOLD:
            threshold_exceeded.append(f"Disk {drive} usage {val}% exceeded the threshold of {DISK_THRESHOLD}%")
            ticket_needed = True
    # Prepare the ticket file content
    ticket_text = []
    if threshold_exceeded and ticket_needed == True:
        ticket_text.append(f"Ticket ID - {Ticket_ID}\n")
        ticket_text.append(f"Affected User - {request.user}\n")
        ticket_text.append(f"Location - India\n")
        ticket_text.append("Category - Hardware\n")
        ticket_text.append(f"Subcategory - Performance\n")
        ticket_text.append(f"Short Description - Threshold Alert for Server: {server_name}\n")
        ticket_text.append("Description - Issues Detected:\n")
        for t in threshold_exceeded:
            ticket_text.append(f"- {t}\n")
        ticket_text.append("Impact - 3 ( Low )\n")
        ticket_text.append("Urgency - 3 ( Low )\n")
        ticket_text.append(f"Assignment Group - L3_{user_unit}TeamcenterPLM_SysAdmin\n")
        ticket_text.append("\nAction: Immediate attention required.\n")
    elif threshold_exceeded and ticket_needed == False:
        for t in threshold_exceeded:
            messages.warning(request,f"{t}\n")
    else:
        ticket_text.append(f"No threshold limit reached for Server: {server_name}\nAll parameters are normal.\n")

    # Save to .txt file
    save_dir = os.path.join(settings.BASE_DIR, 'tickets')
    os.makedirs(save_dir, exist_ok=True)
    file_path = os.path.join(save_dir, f"{Ticket_ID}_{server_name}_ticket.txt")



    if threshold_exceeded and ticket_needed == True:
        messages.warning(request, f"⚠️ Threshold exceeded! Ticket with ID: {Ticket_ID} created successfully at: \n{file_path}")
        Ticket_ID += 1
        with open(file_path, "w") as f:
            f.writelines(ticket_text)
    elif threshold_exceeded and ticket_needed == False:
        messages.warning(request, f"Threshold limit not exceeded but nearing for {server_name}. Hence no ticket created !!")
        # send_email(request, hostname=name)
    else:
        messages.success(request, f"✅ No threshold limit reached for {server_name}. Hence no ticket created !!")

    return redirect('dashboard_view')

# @login_required
# def check_threshold_view(request, server_name):
#     user_unit = request.user.business_unit
#     threshold_exceeded = []
#
#     entry = XMLData.objects.filter(business_unit=user_unit).order_by('-created_at').first()
#     if not entry:
#         return JsonResponse({"status": "error", "message": "No data available for this Business Unit."})
#
#     data_root = entry.data.get('ServiceMetrics') or entry.data.get('ServerMetrics') or entry.data
#     servers = data_root.get('Server', [])
#     if isinstance(servers, dict):
#         servers = [servers]
#
#     selected_server = next((s for s in servers if (s.get('@Hostname') or s.get('Hostname')).lower().replace(' ','') == server_name.lower().replace(' ','')), None)
#     print(selected_server)
#     print(server_name)
#     if not selected_server:
#         return JsonResponse({"status": "error", "message": f"No data found for {server_name}"})
#
#     # Extract metrics
#     cpu_val = ram_val = None
#     disk_vals = []
#     for k, v in selected_server.items():
#         if 'cpu' in k.lower():
#             cpu_val = float(str(v).replace('%', '').strip() or 0)
#         elif 'ram' in k.lower():
#             ram_val = float(str(v).replace('%', '').strip() or 0)
#
#     disks = selected_server.get('Disks', {}).get('Disk', [])
#     if isinstance(disks, dict):
#         disks = [disks]
#
#     for d in disks:
#         drive = d.get('@Drive') or d.get('Drive') or 'Unknown'
#         val = d.get('#text') or d.get('value') or ''
#         num = ''.join(ch for ch in str(val) if ch.isdigit() or ch == '.')
#         disk_vals.append((drive, float(num or 0)))
#
#     # Compare
#     CPU_THRESHOLD, RAM_THRESHOLD, DISK_THRESHOLD = 80, 80, 90
#
#     if cpu_val and cpu_val > CPU_THRESHOLD:
#         threshold_exceeded.append(f"CPU usage {cpu_val}% exceeded threshold ({CPU_THRESHOLD}%)")
#     if ram_val and ram_val > RAM_THRESHOLD:
#         threshold_exceeded.append(f"RAM usage {ram_val}% exceeded threshold ({RAM_THRESHOLD}%)")
#     for drive, val in disk_vals:
#         if val > DISK_THRESHOLD:
#             threshold_exceeded.append(f"Disk {drive} usage {val}% exceeded threshold ({DISK_THRESHOLD}%)")
#
#     # Create ticket file
#     save_dir = os.path.join(settings.BASE_DIR, 'tickets')
#     os.makedirs(save_dir, exist_ok=True)
#     file_path = os.path.join(save_dir, f"{server_name}_ticket.txt")
#
#     if threshold_exceeded:
#         with open(file_path, "w") as f:
#             f.write(f"Threshold Alert for {server_name}\n\n")
#             for line in threshold_exceeded:
#                 f.write(f"- {line}\n")
#         return JsonResponse({
#             "status": "exceeded",
#             "message": "\n".join(threshold_exceeded),
#             "file": file_path
#         })
#     else:
#         with open(file_path, "w") as f:
#             f.write(f"All parameters normal for {server_name}.\n")
#         return JsonResponse({
#             "status": "normal",
#             "message": f"No threshold limit reached for {server_name}."
#         })


@login_required
def graph_dashboard_view(request):
    date_range = request.GET.get("range_type", "24h")
    start_date = request.GET.get("start_date_graph")
    end_date = request.GET.get("end_date_graph")
    selected_metric = request.GET.get("metric_graph", "ALL")
    page_number = request.GET.get("page", 1)
    user_unit = request.user.business_unit
    selected_bu = request.GET.get("bu")

    # ---------------- DATE HANDLING ----------------
    now = timezone.now()
    if date_range == "24h":
        start_datetime = now - timedelta(hours=24)
    elif date_range == "1w":
        start_datetime = now - timedelta(days=7)
    elif date_range == "15d":
        start_datetime = now - timedelta(days=15)
    elif date_range == "1m":
        start_datetime = now - timedelta(days=30)
    elif date_range == "6m":
        start_datetime = now - timedelta(days=180)
    elif date_range == "custom" and start_date and end_date:
        sd = datetime.datetime.strptime(start_date, "%Y-%m-%d").date()
        ed = datetime.datetime.strptime(end_date, "%Y-%m-%d").date()
        start_datetime = timezone.make_aware(datetime.datetime.combine(sd, datetime.time.min))
        now = timezone.make_aware(datetime.datetime.combine(ed, datetime.time.max))
    else:
        start_datetime = None

    end_datetime = now

    # ---------------- BU FILTER ----------------
    if user_unit == "Admin":
        if selected_bu and selected_bu != "ALL":
            entries = ServerMetricsHistory.objects.filter(business_unit=selected_bu)
        else:
            entries = ServerMetricsHistory.objects.all()
    else:
        entries = ServerMetricsHistory.objects.filter(business_unit=user_unit)

    if start_datetime:
        entries = entries.filter(created_at__range=[start_datetime, end_datetime])

    if not entries.exists():
        return render(request, "graph_dashboard.html", {
            "message": "No Server Data found",
            "selectionTab": ["ALL", "CPU", "RAM", "Disks"],
            "metric_graph": selected_metric,
            "date_range": date_range
        })

    # ---------------- AGGREGATION ----------------
    server_agg = {}

    for entry in entries:
        data = entry.data.get("ServiceMetrics") or entry.data.get("ServerMetrics", {})
        servers = data.get("Server", [])
        if isinstance(servers, dict):
            servers = [servers]

        for s in servers:
            name = s.get("@Hostname")
            if not name:
                continue

            cpu = float(str(s.get("CPU", "0")).replace("%", "") or 0)
            ram = float(str(s.get("RAM", "0")).replace("%", "") or 0)

            if name not in server_agg:
                server_agg[name] = {
                    "cpu": [],
                    "ram": [],
                    "disks": {}
                }

            server_agg[name]["cpu"].append(cpu)
            server_agg[name]["ram"].append(ram)

            disks = s.get("Disks", {}).get("Disk", [])
            if isinstance(disks, dict):
                disks = [disks]

            for d in disks:
                drive = d.get("@Drive")
                val = float("".join(c for c in d.get("#text", "") if c.isdigit() or c == ".") or 0)
                server_agg[name]["disks"].setdefault(drive, []).append(val)

    # ---------------- CALCULATE AVERAGES ----------------
    all_servers = []
    for name, vals in server_agg.items():
        avg_cpu = round(sum(vals["cpu"]) / len(vals["cpu"]), 2)
        avg_ram = round(sum(vals["ram"]) / len(vals["ram"]), 2)

        avg_disks = {
            d: round(sum(v) / len(v), 2)
            for d, v in vals["disks"].items()
        }

        all_servers.append({
            "name": name,
            "cpu": avg_cpu,
            "ram": avg_ram,
            "disks": avg_disks
        })

    # ---------------- PAGINATION ----------------
    paginator = Paginator(all_servers, 5)
    page_obj = paginator.get_page(page_number)

    server_names = [s["name"] for s in page_obj]
    cpu_vals = [s["cpu"] for s in page_obj]
    ram_vals = [s["ram"] for s in page_obj]

    # ---------------- DISK ALIGNMENT ----------------
    unique_drives = set()
    for s in page_obj:
        unique_drives.update(s["disks"].keys())

    disk_data = {d: [] for d in unique_drives}

    for s in page_obj:
        for d in unique_drives:
            disk_data[d].append(s["disks"].get(d, 0))

    # ---------------- METRIC FILTER ----------------
    if selected_metric == "CPU":
        ram_vals = []
        disk_data = {}
    elif selected_metric == "RAM":
        cpu_vals = []
        disk_data = {}
    elif selected_metric == "Disks":
        cpu_vals = []
        ram_vals = []

    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    return render(request, "graph_dashboard.html", {
        "name": name.upper(),
        "business_unit":user_unit,
        "server_names": server_names,
        "cpu_vals": cpu_vals,
        "ram_vals": ram_vals,
        "disk_data": json.dumps(disk_data),
        "page_obj": page_obj,
        "selectionTab": ["ALL", "CPU", "RAM", "Disks"],
        "metric_graph": selected_metric,
        "date_range": date_range,
        "start_date_graph": start_date,
        "end_date_graph": end_date,
        "selected_bu": selected_bu,
    })



@csrf_exempt
@login_required
def kill_selected_process(request):
    if request.method != "POST":
        return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)

    data = json.loads(request.body.decode("utf-8"))
    process_name = data.get("process_name")

    if not process_name:
        return JsonResponse({"status": "error", "message": "No process name provided"}, status=400)
    clean_name = process_name.replace(".exe","")
    print(clean_name)
    # clean_name = "".join(ch for ch in clean_name if ch.isalnum())

    try:
        script_path = r"C:\Users\2671706\Downloads\powershellscript.ps1"   # <-- Update this

        result = subprocess.run(
            ["powershell.exe", "-ExecutionPolicy", "Bypass", "-File", script_path, "-ProcessName", clean_name],
            capture_output=True,
            text=True
        )


        return JsonResponse({
            "status": "success",
            "sent_name": clean_name,
            "return_code": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr
        })

    except Exception as e:
        return JsonResponse({
            "status": "error",
            "message": str(e)
        }, status=500)



