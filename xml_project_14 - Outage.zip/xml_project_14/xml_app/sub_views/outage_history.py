from ..views import *

@login_required
def outage_history(request, outage_id):
    outage = PlannedOutage.objects.get(id=outage_id)
    history = outage.history.order_by("-changed_at")

    for h in history:
        data = h.new_data.get('date') or ''
        print(data)

    return render(request, "outage_history.html", {
        "outage": outage,
        "history": history
    })
