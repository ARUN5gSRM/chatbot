from collections import defaultdict

from ..views import *
from ..utils import is_bad_status

@login_required
def application_service_mapping(request, app_id):
    app = Application.objects.get(id=app_id)
    services = app.services.all().order_by('hostname')
    user_unit = request.user.business_unit
    selected_unit = request.GET.get('unit')

    # ----------------- Application Color -------------------- #

    if user_unit == 'Admin':
        if selected_unit and selected_unit != 'All':
            application_entries = ApplicationDashboardLive.objects.filter(business_unit=selected_unit).order_by('-updated_at')
        else:
            application_entries = ApplicationDashboardLive.objects.all().order_by('-updated_at')
    else:
        application_entries = ApplicationDashboardLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    application_color_map = {}
    for entry in application_entries:
        data_root = entry.data.get('ApplicationDashboard') or entry.data.get('Application') or entry.data
        apps = data_root.get('Application', []) if isinstance(data_root, dict) else []
        if isinstance(apps, dict):
            apps = [apps]
        for app_data in apps:
            application_name = app_data.get('Name') or app_data.get('@name') or ''
            application_status = app_data.get('Status') or app_data.get('@status') or ''

            if not application_name:
                continue

            if application_name not in application_color_map:
                application_color_map[application_name] = 'green'

            if is_bad_status(application_status):
                application_color_map[application_name] = 'red'

    print(application_color_map)
    # -------------------------------------------------------- #



    # ------------------- Service Color ----------------------- #

    if user_unit == 'Admin':
        if selected_unit and selected_unit != 'All':
            service_xml_entries = ServiceMetricsLive.objects.filter(business_unit=selected_unit).order_by('-updated_at')
        else:
            service_xml_entries = ServiceMetricsLive.objects.all().order_by('-updated_at')
    else:
        service_xml_entries = ServiceMetricsLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    service_color_map = {}

    for entry in service_xml_entries:
        # prefer files that are service metrics (top tag contains "ServiceMetrics" or filename hints)
        if not isinstance(entry.data, dict) or not entry.data:
            continue
        top = list(entry.data.keys())[0]
        is_metrics = 'servicemetrics' in top.lower() or 'ServiceMetrics' in top


        if not is_metrics:
            continue

        # locate Server nodes
        data_root = entry.data.get(top) if top and top in entry.data else entry.data
        servers = data_root.get('Server', []) if isinstance(data_root, dict) else []
        if isinstance(servers, dict):
            servers = [servers]

        for s in servers:
            host_val = (s.get('@Hostname') or s.get('Hostname') or '').strip()
            if not normalize_key(host_val):
                continue
            service_details = s.get('Service',[]) or s.get('service',[])

            for service in service_details:
                service_name = service.get('@name','')
                service_status = service.get('@status','')

                if not service_name:
                    continue

                if service_name not in service_color_map:
                    service_color_map[service_name] = 'green'

                if is_bad_status(service_status):
                    service_color_map[service_name] = 'red'

    print(service_color_map)


    # -------------------------------------------------------- #


    # ------------------- Server Color ----------------------- #


    if user_unit == 'Admin':
        if selected_unit and selected_unit != 'All':
            xml_entries = ServerMetricsLive.objects.filter(business_unit=selected_unit).order_by('-updated_at')
        else:
            xml_entries = ServerMetricsLive.objects.all().order_by('-updated_at')
    else:
        xml_entries = ServerMetricsLive.objects.filter(business_unit=user_unit).order_by('-updated_at')


    server_color_map = {}
    for entry in xml_entries:
        data = entry.data.get('ServerMetrics', {})
        servers_data = data.get('Server', [])
        if isinstance(servers_data, dict):
            servers_data = [servers_data]

        for server in servers_data:
            server_name = server.get('@Hostname')
            server_status = server.get('@Status')

            if not server_name:
                continue

            if server_name not in server_color_map:
                server_color_map[server_name] = 'green'

            if is_bad_status(server_status):
                server_color_map[server_name] = 'red'

    # -------------------------------------------------------- #
    print(server_color_map)

    hostname_map = defaultdict(list)
    for s in services:
        hostname_map[s.hostname].append(s)

    numberOfServices = len(services)
    print(services)

    email = request.user.email
    user_unit = request.user.business_unit
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    return render(request, "application_service_mapping.html", {
        "application": app,
        "hostname_map": dict(hostname_map),
        "numberOfServices": numberOfServices,
        "app_id": app_id,
        'name': name.upper(),
        'business_unit': user_unit,
        'server_color_map': server_color_map,
        'service_color_map': service_color_map,
        'application_color_map': application_color_map,
    })
