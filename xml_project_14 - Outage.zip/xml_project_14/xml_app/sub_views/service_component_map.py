from ..views import *

@login_required
def service_component_mapping(request, hostname, service_name, app_id):
    hostname = unquote_plus(hostname).strip()
    service_name = unquote_plus(service_name).strip()
    user_unit = request.user.business_unit

    if user_unit == 'Admin':
        entries = ServiceComponentLive.objects.all().order_by('-updated_at')
    else:
        entries = ServiceComponentLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    components = []

    for entry in entries:
        # Only look at ServiceComponent files (top tag or filename)
        if not isinstance(entry.data, dict) or not entry.data:
            continue
        top = list(entry.data.keys())[0]
        is_component_data = 'servicecomponent' in top.lower() or 'ServiceComponent' in top

        if not is_component_data:
            continue

        # data root and Servers list
        data_root = entry.data.get(top) if (top and top in entry.data) else entry.data
        servers = data_root.get('Server', []) if isinstance(data_root, dict) else []
        if isinstance(servers, dict):
            servers = [servers]

        for s in servers:
            host_val = (s.get('@Hostname') or s.get('Hostname') or '').strip()
            print(normalize_key(host_val) == normalize_key(hostname))
            if normalize_key(host_val) != normalize_key(hostname):
                continue

            # services may be under 'service' key as list/dict
            svc_entries = s.get('service') or s.get('Service') or {}
            if isinstance(svc_entries, dict):
                svc_entries = [svc_entries]
            # print(svc_entries)
            if not svc_entries:
                # maybe services are directly children 'service1'...'serviceN' that contain associated_component
                # iterate through s's keys and find those starting with 'service' and containing associated_component
                for k, v in s.items():
                    if not k.lower().startswith('service'):
                        continue
                    sv = v
                    if isinstance(sv, dict):
                        sv_name = sv.get('@name') or sv.get('name') or ''
                        if normalize_key(sv_name) == normalize_key(service_name):
                            assoc = sv.get('associated_component') or sv.get('associated') or sv.get('associated_component_list')
                            if assoc:
                                assoc_list = assoc if isinstance(assoc, list) else [assoc]
                                for comp in assoc_list:
                                    comp_name = comp.get('@name') or comp.get('name') or ''

                                    if comp_name == service_name:
                                        comp_status = comp.get('@status') or comp.get('status') or ''
                                        comp_url = comp.get('@url') or comp.get('url') or ''
                                        comp_log = (comp.get('@logFile') or comp.get('logfile') or '')
                                        actual_service = comp.get('@actual_service_name') or comp.get('actual_service_name') or ''
                                        components.append({
                                            'component_name': comp_name,
                                            'status': comp_status,
                                            'url': comp_url,
                                            'logfile': comp_log,
                                            'actual_service': actual_service
                                        })
                continue

            # Now svc_entries is a list of service dicts — find the matching one by @name
            for sv in svc_entries:
                if not isinstance(sv, dict):
                    continue
                sv_name = (sv.get('@name') or sv.get('name') or '').strip()
                if normalize_key(sv_name) != normalize_key(service_name):
                    continue
                assoc = sv.get('associated_component') or sv.get('associated') or sv.get('associated_component_list')
                if not assoc:
                    continue
                assoc_list = assoc if isinstance(assoc, list) else [assoc]
                for comp in assoc_list:
                    print(comp)
                    comp_name = comp.get('@name') or comp.get('name') or ''
                    comp_status = comp.get('@status') or comp.get('status') or ''
                    comp_url = comp.get('@url') or comp.get('url') or ''
                    comp_log = comp.get('@logFile') or comp.get('@logfile') or comp.get('logFile') or comp.get('logfile') or ''
                    actual_service = comp.get('@actual_service_name') or comp.get('actual_service_name') or ''
                    components.append({
                        'component_name': comp_name,
                        'status': comp_status,
                        'url': comp_url,
                        'logfile': comp_log,
                        'actual_service': actual_service,
                    })
    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)
    # sort components by name
    # components = sorted(components, key=lambda x: (x.get('component_name') or '').lower())
    return render(request, 'service_component_mapping.html', {
        'hostname': hostname,
        'service_name': service_name,
        'components': components,
        'name': name.upper(),
        'business_unit': user_unit,
        'app_id': app_id,
    })
