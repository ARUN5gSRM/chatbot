from ..views import *
from ..utils import is_bad_status

@login_required
def application_mapping(request):
    user_bu = request.user.business_unit
    selected_bu = request.GET.get("bu")

    if user_bu == "Admin":
        if selected_bu and selected_bu != "ALL":
            bu_filter = selected_bu
        else:
            bu_filter = None
    else:
        bu_filter = user_bu

    # --- APPLICATION HEALTH ---
    app_entries = ApplicationDashboardLive.objects.all()
    if bu_filter:
        app_entries = app_entries.filter(business_unit=bu_filter)

    application_health_bad = False
    for entry in app_entries:
        data = entry.data.get("ApplicationDashboard", {})
        apps = data.get("Application", [])
        if isinstance(apps, dict):
            apps = [apps]

        for app in apps:
            if is_bad_status(app.get("Status") or app.get("@status")):
                application_health_bad = True
                break

    # --- SERVICE HEALTH ---
    svc_entries = ServiceMetricsLive.objects.all()
    if bu_filter:
        svc_entries = svc_entries.filter(business_unit=bu_filter)

    service_health_bad = False
    for entry in svc_entries:
        data = entry.data.get("ServiceMetrics", {})
        servers = data.get("Server", [])
        if isinstance(servers, dict):
            servers = [servers]

        for s in servers:
            services = s.get("Service", [])
            if isinstance(services, dict):
                services = [services]

            for svc in services:
                if is_bad_status(svc.get("@status")):
                    service_health_bad = True
                    break

    # --- SERVER HEALTH ---
    srv_entries = ServerMetricsLive.objects.all()
    if bu_filter:
        srv_entries = srv_entries.filter(business_unit=bu_filter)

    server_health_bad = False
    for entry in srv_entries:
        data = entry.data.get("ServerMetrics", {})
        servers = data.get("Server", [])
        if isinstance(servers, dict):
            servers = [servers]

        for s in servers:
            if is_bad_status(s.get("@Status")):
                server_health_bad = True
                break

    # --- APPLICATION LIST ---
    apps = Application.objects.all()
    if bu_filter:
        apps = apps.filter(business_unit=bu_filter)

    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    context = {
        "prod_apps": apps.filter(environment="PROD"),
        "qa_apps": apps.filter(environment="QA"),
        "dev_apps": apps.filter(environment="DEV"),

        "application_health_bad": application_health_bad,
        "service_health_bad": service_health_bad,
        "server_health_bad": server_health_bad,

        "selected_bu": selected_bu or "ALL",
        "business_unit": user_bu,
        'name': name.upper(),
    }

    return render(request, "application_mapping.html", context)

