from ..views import *

@login_required
def latest_event_detail_mapping(request, hostname, app_id):
    hostname = unquote(hostname).strip()
    user_unit = request.user.business_unit

    if user_unit == 'Admin':
        entries = ServerMetricsLive.objects.all().order_by("updated_at")
    else:
        entries = ServerMetricsLive.objects.filter(business_unit = user_unit).order_by("-updated_at")

    event_details = []

    for entry in entries:
        datas = entry.data.get('ServerMetrics',{})
        servers = datas.get('Server',[])

        for server in servers:
            server_name = server.get('@Hostname') or servers.get('@HostName') or servers.get('HostName')
            if server_name != hostname:
                continue
            events = server.get('LatestEvents',{}).get('Event',[])

            for event in events:
                event_details.append({
                    'event_time': event.get('@Time',''),
                    'event_id': event.get('@ID',''),
                    'event_level': event.get('@Level',''),
                    'event_text': event.get('#text','')
                })

    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)
    print(event_details)
    return render(request, "latest_events_detail_mapping.html",{
        'name': name.upper(),
        'business_unit':user_unit,
        'event_details':event_details,
        'hostname':hostname,
        'app_id':app_id,
    })