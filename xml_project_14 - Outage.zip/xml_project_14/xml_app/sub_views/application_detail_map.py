from ..views import *
from ..utils import is_bad_status
@login_required
def application_detail_mapping(request, application_name, app_id):
    user_unit = request.user.business_unit
    selected_unit = request.GET.get('app_unit')

    if user_unit == 'Admin':
        if selected_unit and selected_unit != 'All':
            entries = ApplicationDashboardLive.objects.filter(business_unit=selected_unit).order_by('-updated_at')
        else:
            entries = ApplicationDashboardLive.objects.all().order_by('-updated_at')
    else:
        entries = ApplicationDashboardLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    # print(entries)
    # print(application_name)
    applications = []
    for entry in entries:
        data_root = entry.data.get('ApplicationDashboard') or entry.data.get('Application') or entry.data
        apps = data_root.get('Application', []) if isinstance(data_root, dict) else []
        if isinstance(apps, dict):
            apps = [apps]
        for app in apps:
            name = app.get('Name') or app.get('@name') or ''
            if name == application_name:
                status = app.get('Status') or app.get('@status') or ''
                availability_uptime_percent = app.get('AvailabilityUptimePercent') or ''
                response_time_ms = app.get('ResponseTimeMs') or ''
                latency_ms = app.get('LatencyMs') or ''
                throughput_rps = app.get('ThroughputRPS') or ''
                database_query_latency_ms = app.get('DatabaseQueryLatencyMs') or ''
                error_rate_percent = app.get('ErrorRatePercent') or ''
                load_balancer_request_count = app.get('LoadBalancerRequestCount') or ''
                print(status)
                if name:
                    applications.append({
                        'name': name.strip(),
                        'status_color': get_color(status),
                        'status': status,
                        'availability_uptime_percent': availability_uptime_percent,
                        'response_time_ms': response_time_ms,
                        'latency_ms': latency_ms,
                        'throughput_rps': throughput_rps,
                        'database_query_latency_ms': database_query_latency_ms,
                        'error_rate_percent': error_rate_percent,
                        'load_balancer_request_count': load_balancer_request_count,
                        'file': entry.app_name,
                    })

    # ----------------------- Application Color based on servers running on it ------------------

    resolved_name = normalize_pool_group(application_name)

    if user_unit == 'Admin':
        app_entries = ApplicationListLive.objects.all().order_by('-updated_at')
    else:
        app_entries = ApplicationListLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    servers = []
    appServer_color_map = {}
    for entry in app_entries:
        data_root = entry.data.get('ApplicationList') or entry.data.get('Application') or entry.data
        apps = data_root.get('Application', []) if isinstance(data_root, dict) else []
        if isinstance(apps, dict):
            apps = [apps]

        for app in apps:
            name = app.get('@name') or app.get('Name')
            if not name or name.strip().lower() != resolved_name.lower():
                continue

            srv_list = app.get('Server', [])
            if isinstance(srv_list, dict):
                srv_list = [srv_list]

            for s in srv_list:

                app_server_name = s.get('@name')
                app_server_status = s.get('@status')
                print(app_server_name)
                print(app_server_status)

                if resolved_name not in appServer_color_map:
                    appServer_color_map[resolved_name] = 'green'

                if is_bad_status(app_server_status):
                    appServer_color_map[resolved_name] = 'red'
                    break

    print(appServer_color_map)
    # -------------------------------------------------------------------------------------------
    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    return render(request, 'application_detail_mapping.html', {
        'applications': applications,
        'name': name.upper(),
        'selected_unit': selected_unit or 'All',
        'business_unit': user_unit,
        "app_id": app_id,
        'appServer_color_map': appServer_color_map,
    })

def get_color(value):
    if isinstance(value, list):
        disk_colors = []
        for d_value in value:
            if "Free" in d_value:
                d = re.search(r"(\d+\.\d+|\d+)GB", d_value)
                if float(d.group(1)) > 25:
                    disk_colors.append('green')
                elif float(d.group(1)) <= 25 and float(d.group(1)) > 10:
                    disk_colors.append('orange')
                else:
                    disk_colors.append('red')
        diskspace_data = [
            {"value": v, "colors": c}
            for v,c in zip(value, disk_colors)
        ]
        return diskspace_data


    # for string values
    if value.lower() == "up" or value.lower() == "running" or value == "True":
        return '#008000'
    elif value.lower() == "down" or value.lower() == "stopped" or value == "False":
        return 'red'
    elif not value:
        return 'green'

    try:
        if "%" in value:
            v = float(str(value).replace('%', '').strip())
            if v <= 65:
                return 'green'
            elif v <= 85:
                return 'yellow'
            else:
                return 'red'
        if "MB" in value:
            r = float(str(value).replace('MB', '').strip())
            if r > 10000:
                return 'green'
            elif r <= 10000 and r > 6000:
                return 'orange'
            else:
                return 'red'
        if "Free" in value:
            d = re.search(r"(\d+\.\d+|\d+)GB", value)
            print(d.group(1))
            if d.group(1) > 25:
                return 'green'
            elif d.group(1) <= 25 and d.group(1) > 10:
                return 'orange'
            else:
                return 'red'

    except Exception:
        return 'green'


def normalize_pool_group(app_name):
    """
    Detect GS/BGS pools and map to their base module (T4X) dynamically.
    """
    if "POOL_GS" in app_name or "POOL_BGS" in app_name:
        # base_module = everything before GS/BGS + "_T4X"
        # detect prefix (e.g., ABC_, XYZ_)
        match = re.match(r"([A-Z0-9_]+)_POOL_", app_name)
        if match:
            prefix = match.group(1)
            return f"{prefix}_POOL_T4X"
    return app_name

