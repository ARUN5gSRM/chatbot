from ..views import *

@login_required
def application_server_mapping(request, app_name, app_id):
    app_name = unquote_plus(app_name).strip()
    user_unit = request.user.business_unit

    resolved_name = normalize_pool_group(app_name)

    if user_unit == 'Admin':
        entries = ApplicationListLive.objects.all().order_by('-updated_at')
    else:
        entries = ApplicationListLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    servers = []
    for entry in entries:
        data_root = entry.data.get('ApplicationList') or entry.data.get('Application') or entry.data
        apps = data_root.get('Application', []) if isinstance(data_root, dict) else []
        if isinstance(apps, dict):
            apps = [apps]

        for app in apps:
            name = app.get('@name') or app.get('Name')
            if not name or name.strip().lower() != resolved_name.lower():
                continue

            srv_list = app.get('Server', [])
            if isinstance(srv_list, dict):
                srv_list = [srv_list]

            for s in srv_list:
                servers.append({
                    'name': s.get('@name') or '',
                    # 'env': s.get('@env') or '',
                    'hostname': s.get('@hostname') or '',
                    'cpu_color': get_app_cpu_color(s.get('@cpu') or ''),
                    'cpu': s.get('@cpu') or '',
                    'ram_color': get_color(s.get('@ram') or ''),
                    'ram': s.get('@ram') or '',
                    'diskspace_data': get_color((s.get('@diskspace').split(',') or '')),
                    # 'diskspace': (s.get('@diskspace') or '').split(','),
                    'pingstatus': s.get('@pingstatus') or '',
                    'lastchecked': s.get('@lastchecked') or '',
                    'status': s.get('@status') or '',
                })

    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    return render(request, 'application_server_mapping.html', {
        'app_name': app_name,
        'servers': servers,
        'name': name.upper(),
        'business_unit': user_unit,
        'app_id': app_id,
    })


def normalize_pool_group(app_name):
    """
    Detect GS/BGS pools and map to their base module (T4X) dynamically.
    """
    if "POOL_GS" in app_name or "POOL_BGS" in app_name:
        # base_module = everything before GS/BGS + "_T4X"
        # detect prefix (e.g., ABC_, XYZ_)
        match = re.match(r"([A-Z0-9_]+)_POOL_", app_name)
        if match:
            prefix = match.group(1)
            return f"{prefix}_POOL_T4X"
    return app_name

def get_app_cpu_color(value):
    try:
        if "%" in value:
            v = float(str(value).replace('%', '').strip())
            if v <= 65:
                return 'green'
            elif v <= 85:
                return 'orange'
            else:
                return 'red'
    except Exception:
        return 'green'


def get_color(value):
    if isinstance(value, list):
        disk_colors = []
        for d_value in value:
            if "Free" in d_value:
                d = re.search(r"(\d+\.\d+|\d+)GB", d_value)
                if float(d.group(1)) > 25:
                    disk_colors.append('green')
                elif float(d.group(1)) <= 25 and float(d.group(1)) > 10:
                    disk_colors.append('orange')
                else:
                    disk_colors.append('red')
        diskspace_data = [
            {"value": v, "colors": c}
            for v,c in zip(value, disk_colors)
        ]
        return diskspace_data


    # for string values
    if value.lower() == "up" or value.lower() == "running" or value == "True":
        return '#008000'
    elif value.lower() == "down" or value.lower() == "stopped" or value == "False":
        return 'red'
    elif not value:
        return 'green'

    try:
        if "%" in value:
            v = float(str(value).replace('%', '').strip())
            if v <= 65:
                return 'green'
            elif v <= 85:
                return 'yellow'
            else:
                return 'red'
        if "MB" in value:
            r = float(str(value).replace('MB', '').strip())
            if r > 10000:
                return 'green'
            elif r <= 10000 and r > 6000:
                return 'orange'
            else:
                return 'red'
        if "Free" in value:
            d = re.search(r"(\d+\.\d+|\d+)GB", value)
            print(d.group(1))
            if d.group(1) > 25:
                return 'green'
            elif d.group(1) <= 25 and d.group(1) > 10:
                return 'orange'
            else:
                return 'red'

    except Exception:
        return 'green'
