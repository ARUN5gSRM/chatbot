from ..utils import is_bad_status
from ..views import *

@login_required
def service_mapping(request, hostname, service_name, app_id):
    hostname = unquote_plus(hostname).strip()
    service_name = unquote_plus(service_name).strip()
    user_unit = request.user.business_unit

    # choose entries visible to user
    if user_unit == 'Admin':
        entries = ServiceMetricsLive.objects.all().order_by('-updated_at')
    else:
        entries = ServiceMetricsLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    hostname_for_serviceComponent = ""
    servicename_for_serviceComponent = ""
    serviceComponent_color_map = {}

    # svc_map = {}  # normalized_service_name -> {service_name, status, source_file, uploaded_at}
    svc_map = []
    for entry in entries:
        # prefer files that are service metrics (top tag contains "ServiceMetrics" or filename hints)
        if not isinstance(entry.data, dict) or not entry.data:
            continue
        top = list(entry.data.keys())[0]
        is_metrics = 'servicemetrics' in top.lower() or 'ServiceMetrics' in top


        if not is_metrics:
            continue

        # locate Server nodes
        data_root = entry.data.get(top) if top and top in entry.data else entry.data
        servers = data_root.get('Server', []) if isinstance(data_root, dict) else []
        if isinstance(servers, dict):
            servers = [servers]

        for s in servers:
            host_val = (s.get('@Hostname') or s.get('Hostname') or '').strip()
            if normalize_key(host_val) != normalize_key(hostname):
                continue
            service_details = s.get('Service',[]) or s.get('service',[])
            hostname_for_serviceComponent = host_val
            for service in service_details:
                if service.get('@name','') == service_name:
                    servicename_for_serviceComponent = service_name
                    svc_map.append({
                        'hostname': host_val,
                        'svc_name': service.get('@name',''),
                        'svc_status': service.get('@status',''),
                        'status_color': get_color(service.get('@status','')),
                        'svc_lastchecked': service.get('@lastchecked',''),
                        'svc_responsetime': service.get('@responsetime',''),
                        'svc_availability': service.get('@availability',''),
                        'svc_errorrate': service.get('@errorrate',''),
                        'svc_restartcount': service.get('@restartcount',''),
                    })

    # ----------------Service color based on Service Component Status ---------------------

    if user_unit == 'Admin':
        entries = ServiceComponentLive.objects.all().order_by('-updated_at')
    else:
        entries = ServiceComponentLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    components = []

    for entry in entries:
        # Only look at ServiceComponent files (top tag or filename)
        if not isinstance(entry.data, dict) or not entry.data:
            continue
        top = list(entry.data.keys())[0]
        is_component_data = 'servicecomponent' in top.lower() or 'ServiceComponent' in top

        if not is_component_data:
            continue

        # data root and Servers list
        data_root = entry.data.get(top) if (top and top in entry.data) else entry.data
        servers = data_root.get('Server', []) if isinstance(data_root, dict) else []
        if isinstance(servers, dict):
            servers = [servers]

        for s in servers:
            host_val = (s.get('@Hostname') or s.get('Hostname') or '').strip()
            print(normalize_key(host_val) == normalize_key(hostname))
            if normalize_key(host_val) != normalize_key(hostname):
                continue

            svc_entries = s.get('service') or s.get('Service') or {}
            if isinstance(svc_entries, dict):
                svc_entries = [svc_entries]
            # print(svc_entries)
            if not svc_entries:
                continue
            for sv in svc_entries:
                if not isinstance(sv, dict):
                    continue
                sv_name = (sv.get('@name') or sv.get('name') or '').strip()
                if normalize_key(sv_name) != normalize_key(service_name):
                    continue
                assoc = sv.get('associated_component') or sv.get('associated') or sv.get('associated_component_list')
                if not assoc:
                    continue
                assoc_list = assoc if isinstance(assoc, list) else [assoc]
                for comp in assoc_list:
                    comp_name = comp.get('@name') or comp.get('name') or ''
                    comp_status = comp.get('@status') or comp.get('status') or ''
                    print(hostname_for_serviceComponent)
                    print(servicename_for_serviceComponent)
                    print(comp_name)
                    print(comp_status)

                    if comp_name not in serviceComponent_color_map:
                        serviceComponent_color_map[service_name] = 'green'

                    if is_bad_status(comp_status):
                        serviceComponent_color_map[service_name] = 'red'
                        break

    print(serviceComponent_color_map)

    # -------------------------------------------------------------------------------------

    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    print(svc_map)
    return render(request, 'service_mapping.html', {
        'hostname': hostname,
        # 'services': services,
        'services':svc_map,
        'name': name.upper(),
        'business_unit': user_unit,
        'app_id': app_id,
        'serviceComponent_color_map':serviceComponent_color_map,
    })

def get_color(value):
    if isinstance(value, list):
        disk_colors = []
        for d_value in value:
            if "Free" in d_value:
                d = re.search(r"(\d+\.\d+|\d+)GB", d_value)
                if float(d.group(1)) > 25:
                    disk_colors.append('green')
                elif float(d.group(1)) <= 25 and float(d.group(1)) > 10:
                    disk_colors.append('orange')
                else:
                    disk_colors.append('red')
        diskspace_data = [
            {"value": v, "colors": c}
            for v,c in zip(value, disk_colors)
        ]
        return diskspace_data


    # for string values
    if value.lower() == "up" or value.lower() == "running" or value == "True":
        return '#008000'
    elif value.lower() == "down" or value.lower() == "stopped" or value == "False":
        return 'red'
    elif not value:
        return 'green'

    try:
        if "%" in value:
            v = float(str(value).replace('%', '').strip())
            if v <= 65:
                return 'green'
            elif v <= 85:
                return 'yellow'
            else:
                return 'red'
        if "MB" in value:
            r = float(str(value).replace('MB', '').strip())
            if r > 10000:
                return 'green'
            elif r <= 10000 and r > 6000:
                return 'orange'
            else:
                return 'red'
        if "Free" in value:
            d = re.search(r"(\d+\.\d+|\d+)GB", value)
            print(d.group(1))
            if d.group(1) > 25:
                return 'green'
            elif d.group(1) <= 25 and d.group(1) > 10:
                return 'orange'
            else:
                return 'red'

    except Exception:
        return 'green'
