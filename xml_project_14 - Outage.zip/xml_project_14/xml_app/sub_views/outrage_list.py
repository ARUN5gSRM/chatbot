from ..views import *
from ..models import PlannedOutage

@login_required
def outage_list(request):
    user_bu = request.user.business_unit

    if user_bu == "Admin":
        outages = PlannedOutage.objects.all().order_by("-date")
    else:
        outages = PlannedOutage.objects.filter(
            business_unit=user_bu
        ).order_by("-date")

    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    return render(request, "outrage_list.html", {
        "outages": outages,
        "business_unit": user_bu,
        "name": name.upper(),
    })
