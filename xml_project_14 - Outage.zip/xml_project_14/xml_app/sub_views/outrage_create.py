from ..views import *
from ..models import PlannedOutage
@login_required
def outage_create(request):
    if request.method == "POST":
        # PlannedOutage.objects.create(
        #     business_unit=request.user.business_unit,
        #     date=request.POST["date"],
        #     planned_start_time=request.POST["start_time"],
        #     planned_end_time=request.POST["end_time"],
        #     planned_delay=request.POST["delay"],
        #     remarks=request.POST.get("remarks", ""),
        #     created_by=request.user,
        # )
        outage = PlannedOutage.objects.create(
            business_unit=request.user.business_unit,
            date=request.POST.get("date"),
            planned_start_time=request.POST.get("start_time"),
            planned_end_time=request.POST.get("end_time"),
            planned_delay=request.POST.get("delay"),
            remarks=request.POST.get("remarks"),
            created_by=request.user,  # ✅ IMPORTANT
        )

        # 2️⃣ Create history entry (ADD THIS PART)
        PlannedOutageHistory.objects.create(
            outage=outage,
            action="CREATED",
            changed_by=request.user,  # ✅ USER OBJECT
            old_data=None,
            new_data={
                "business_unit": outage.business_unit,
                "date": str(outage.date),
                "start_time": str(outage.planned_start_time),
                "end_time": str(outage.planned_end_time),
                "delay": outage.planned_delay,
                "remarks": outage.remarks,
            },
            remarks="Outage created",
        )

        return redirect("outage_list")

    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    return render(request, "outrage_form.html", {
        "mode": "Create",
        "name": name.upper(),
        "business_unit": request.user.business_unit,
    })
