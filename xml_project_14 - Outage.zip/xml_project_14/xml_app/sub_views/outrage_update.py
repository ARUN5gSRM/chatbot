from ..views import *
from ..models import PlannedOutage

@login_required
def outage_update(request, pk):
    outage = get_object_or_404(PlannedOutage, pk=pk)

    # Security: BU users can update only their BU
    if request.user.business_unit != "Admin" and outage.business_unit != request.user.business_unit:
        return redirect("outage_list")

    # if request.method == "POST":
    #     outage.date = request.POST["date"]
    #     outage.planned_start_time = request.POST["start_time"]
    #     outage.planned_end_time = request.POST["end_time"]
    #     outage.planned_delay = request.POST["delay"]
    #     outage.remarks = request.POST.get("remarks", "")
    #     outage.save()

    old_data = {
        "business_unit": outage.business_unit,
        "date": str(outage.date),
        "planned_start_time": str(outage.planned_start_time),
        "planned_end_time": str(outage.planned_end_time),
        "planned_delay": outage.planned_delay,
        "remarks": outage.remarks,
    }

    if request.method == "POST":
        outage.business_unit = request.user.business_unit
        outage.date = request.POST.get("date")
        outage.planned_start_time = request.POST.get("start_time")
        outage.planned_end_time = request.POST.get("end_time")
        outage.planned_delay = request.POST.get("delay")
        outage.remarks = request.POST.get("remarks")
        outage.save()

        # 🔹 Capture NEW data
        new_data = {
            "business_unit": outage.business_unit,
            "date": str(outage.date),
            "start_time": str(outage.planned_start_time),
            "end_time": str(outage.planned_end_time),
            "delay": outage.planned_delay,
            "remarks": outage.remarks,
        }

        # 🔹 Save history
        PlannedOutageHistory.objects.create(
            outage=outage,
            action="UPDATED",
            changed_by=request.user,
            old_data=old_data,
            new_data=new_data,
            remarks="Outage updated",
        )

        return redirect("outage_list")

    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    return render(request, "outrage_form.html", {
        "mode": "Update",
        "outage": outage,
        "business_unit": request.user.business_unit,
        "name": name.upper()
    })

