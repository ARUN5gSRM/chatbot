from ..views import *

CPU_THRESHOLD_WARNING = 65
RAM_THRESHOLD_WARNING = 65
DISK_THRESHOLD_WARNING = 65

CPU_THRESHOLD = 85
RAM_THRESHOLD = 85
DISK_THRESHOLD = 85

KILL_CPU_THRESHOLD = 85
KILL_RAM_THRESHOLD = 85
KILL_DISK_THRESHOLD = 85

@login_required
def server_detail_mapping(request, hostname, app_id):
    user_unit = request.user.business_unit
    selected_unit = request.GET.get('unit')  # from dropdown filter

    # Admin can filter by any unit or see all
    if user_unit == 'Admin':
        if selected_unit and selected_unit != 'All':
            xml_entries = ServerMetricsLive.objects.filter(business_unit=selected_unit).order_by('-updated_at')
        else:
            xml_entries = ServerMetricsLive.objects.all().order_by('-updated_at')
    else:
        # Regular users can only see their own unit’s data
        xml_entries = ServerMetricsLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    # build servers data for template
    servers = []
    for entry in xml_entries:
        data = entry.data.get('ServerMetrics', {})
        servers_data = data.get('Server', [])
        if isinstance(servers_data, dict):
            servers_data = [servers_data]

        for server in servers_data:
            name = server.get('@Hostname','')

            if name == hostname:

                cpu_val = float(str(server.get('CPU')).replace('%', '').strip() or 0)
                ram_val = float(str(server.get('RAM')).replace('%', '').strip() or 0)
                threshold_breach_cpu = cpu_val > KILL_CPU_THRESHOLD
                threshold_breach_ram = ram_val > KILL_RAM_THRESHOLD

                disks = server.get('Disks', {}).get('Disk', [])
                if isinstance(disks, dict):
                    disks = [disks]
                disk_list = []
                disk_value_check = []
                for d in disks:
                    drive = d.get('@Drive', '')
                    usage = d.get('#text', '')
                    disk_value_check.append(usage)
                    disk_list.append({
                        'drive': drive,
                        'usage': usage,
                        'color': get_color(usage)
                    })

                # disk value threshold check condition
                disk_value_condition = False
                for value in disk_value_check:
                    if float(str(value).replace('%', '')) > KILL_DISK_THRESHOLD:
                        disk_value_condition = True
                        break

                threshold_breach_disk = disk_value_condition

                contributor_list = server.get('TopMemoryProcesses', {}).get('Process', [])
                if isinstance(contributor_list, dict):
                    contributor_list = [contributor_list]
                top_3 = []
                for contributor in contributor_list:
                    process_name = contributor.get('@Name', '')
                    process_used = contributor.get('@MemoryGB', '')
                    top_3.append({
                        'process_name': process_name,
                        'process_used': process_used,
                    })
                servers.append({
                    # 'source_file': entry.file_name,
                    # 'uploaded_at': entry.created_at,
                    'hostname': server.get('@Hostname'),
                    'ip': server.get('@IP'),
                    'status': server.get('@Status'),
                    'status_color': get_color(server.get('@Status')),
                    'cpu': server.get('CPU'),
                    'ram': server.get('RAM'),
                    'cpu_color': get_color(server.get('CPU')),
                    'ram_color': get_color(server.get('RAM')),
                    'network_latency': server.get('Network_Latency'),
                    'last_boot': server.get('Last_Boot_Time'),
                    'disks': disk_list,
                    'top_memory_processes': top_3,
                    'threshold_breach_cpu': threshold_breach_cpu,
                    'threshold_breach_ram': threshold_breach_ram,
                    'threshold_breach_disk': threshold_breach_disk,
                    'cpu_threshold': CPU_THRESHOLD,
                    'ram_threshold': RAM_THRESHOLD,
                    'disk_threshold': DISK_THRESHOLD,
                })
    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    return render(request, 'server_detail_mapping.html', {
        'servers': servers,
        'business_unit': user_unit,
        'selected_unit': selected_unit or 'All',
        'name': name.upper(),
        'app_id':app_id,
    })

def get_color(value):
    if isinstance(value, list):
        disk_colors = []
        for d_value in value:
            if "Free" in d_value:
                d = re.search(r"(\d+\.\d+|\d+)GB", d_value)
                if float(d.group(1)) > 25:
                    disk_colors.append('green')
                elif float(d.group(1)) <= 25 and float(d.group(1)) > 10:
                    disk_colors.append('orange')
                else:
                    disk_colors.append('red')
        diskspace_data = [
            {"value": v, "colors": c}
            for v,c in zip(value, disk_colors)
        ]
        return diskspace_data


    # for string values
    if value.lower() == "up" or value.lower() == "running" or value == "True":
        return '#008000'
    elif value.lower() == "down" or value.lower() == "stopped" or value == "False":
        return 'red'
    elif not value:
        return 'green'

    try:
        if "%" in value:
            v = float(str(value).replace('%', '').strip())
            if v <= 65:
                return 'green'
            elif v <= 85:
                return 'yellow'
            else:
                return 'red'
        if "MB" in value:
            r = float(str(value).replace('MB', '').strip())
            if r > 10000:
                return 'green'
            elif r <= 10000 and r > 6000:
                return 'orange'
            else:
                return 'red'
        if "Free" in value:
            d = re.search(r"(\d+\.\d+|\d+)GB", value)
            print(d.group(1))
            if d.group(1) > 25:
                return 'green'
            elif d.group(1) <= 25 and d.group(1) > 10:
                return 'orange'
            else:
                return 'red'

    except Exception:
        return 'green'
