from ..views import *


@login_required
def application_server_more_details_mapping(request, app_name, server_name, app_id):
    server_name = unquote(server_name).strip()
    app_name = unquote(app_name).strip()
    user_unit = request.user.business_unit

    if user_unit == 'Admin':
        entries = ApplicationListLive.objects.all().order_by('-updated_at')
    else:
        entries = ApplicationListLive.objects.filter(business_unit=user_unit).order_by('-updated_at')

    details = None

    for entry in entries:
        data_root = entry.data.get('ApplicationList') or entry.data.get('Application') or entry.data
        apps = data_root.get('Application', []) if isinstance(data_root, dict) else []
        if isinstance(apps, dict):
            apps = [apps]

        for app in apps:
            name = app.get('@name') or app.get('Name')
            if not name or name.strip().lower() != app_name.lower():
                continue

            srv_list = app.get('Server', [])
            if isinstance(srv_list, dict):
                srv_list = [srv_list]

            for s in srv_list:
                if (s.get('@name') or '').strip().lower() == server_name.lower():

                    details = {
                        'server_name': server_name,
                        'ip': s.get('@ip') or '',
                        'os': s.get('@os') or '',
                        'os_version_build': s.get('@os_version_build') or '',
                        'network': s.get('@network') or '',
                        'remoteenabled': s.get('@remoteenabled') or '',
                    }
                    break

    if not details:
        messages.error(request, "Server details not found.")
        return redirect('application_server_mapping', app_name=app_name)

    email = request.user.email
    pattern = "@[\w\.-]*"
    name = re.sub(pattern, ' ', email)

    return render(request, "application_server_more_details_mapping.html", {
        "app_name": app_name,
        "details": details,
        'name': name.upper(),
        'business_unit': user_unit,
        'app_id': app_id,
    })

