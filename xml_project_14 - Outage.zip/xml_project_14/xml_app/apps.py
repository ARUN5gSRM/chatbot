from django.apps import AppConfig


class XmlAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'xml_app'
